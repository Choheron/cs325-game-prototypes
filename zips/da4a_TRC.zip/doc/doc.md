#	Digital Assignment 4A - Prototype
*	**Originality:**	The game is based around a procedural sight system that allows the player to have mystery and an area of viewing in the game.
*	**Technical	Merit:**	As usual, my games focus a lot more on the systems programming side of things as I really enjoy creating complicated and interesting
systems for the game.
*	**Prototype	Postmortem:**	I learned a lot about calculating distances and clamping the values required.
*	**Prototype	Assets:**	ALL assets made from scratch.
*	**Prototype	Closest	Other	Game:**	Similar to games where fog of war is in play. (NO CODE USED FROM OTHER GAMES)
*	**High	Concept:**	The prototype is currently just a proof of concept for the sight and rendering system in the game.
*	**Theme:** None (Not required)
*	**Prototype	Goal:**	Testing the hidden system in the grid based off of proximity and vision.
*	**Player	Experience	Goals:**	I want my players to enjoy the gameplay and make their own fun when this prototype has been expanded into an entire game.
*	**Gameplay:**	CURRENTLY A PROTOTYPE (N/A)
*	**Strategies:**	Slow paced and deliberate gameplay.
*	**Target	Audience:**	Anyone interested in stealth/movement based games.
*	**Play	Time:**	N/A