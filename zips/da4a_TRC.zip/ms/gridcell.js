GridCell = class {
  // Constructor
  constructor(name, collisionType, xPos, yPos, size, floorSprite) {
    this.name = name;
    this.collision = collisionType;
    
    this.X = xPos;
    this.Y = yPos;
    this.size = size;
    
    this.floorSprite = floorSprite;
    this.item = null;
    
    // Controls the draw function
    this.visible = 1;
  }
  
  // Set the object reference of the item (for it being occupied by something)
  setItem = function(itemIn) {
    this.item = itemIn;
  }
  
  setVisible = function(visible){
    this.visible = visible;
  }
  
  // X Position Getter
  getX = function() {
    return this.X;
  }
  
  // Set the new X location of the cell
  setX = function(newX, newWorldX) {
    this.X = newX;
  }
  
  // Y Position Getter
  getY = function() {
    return this.Y;
  }
  
  // Set the new Y location of the cell
  setY = function(newY, newWorldY) {
    this.Y = newY;
  }
  
  draw = function() {
    if(this.visible < 1) {
      // Draw Floor Sprite
      screen.drawSprite(this.floorSprite, this.X, this.Y, this.size, this.size);
    }
    
    // Place fog of war based off of distance values
    if(this.visible != 0) {
      screen.fillRect(this.X, this.Y, this.size, this.size, "rgba(0,0,0," + this.visible + ")");
      screen.drawText(this.visible.toFixed(2), this.X, this.Y, 5, "rgb(255,0,0)");
      return;
    }
    
    // Draw item if there is one and the cell is visible
    if(this.item) {
      this.item.draw();
    }
  }
  
  update = function() {
    
  }
}