init = function() {
  cellSize = 15;
  // Grid Constructor:  constructor(centerX, centerY, cellSize, width, height)
  gridMap = new Grid(0, 0, cellSize, 30, 30);
  
  // Player Constructor: constructor(sprite, size, health, sight, gridX, gridY, gridRef)
  player = new Player("player_t", cellSize, 10, 5, 15, 15, gridMap);
  
  // Set the player reference in the grid and place the player
  gridMap.setPlayerRef(player);
}

update = function() {
  // Update player
  player.update();
  
  // Update Grid
  gridMap.update();
}

draw = function() {
  // Draw Grid
  gridMap.draw();
}