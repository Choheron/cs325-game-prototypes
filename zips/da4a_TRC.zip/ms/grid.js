Grid = class {
  constructor(centerX, centerY, cellSize, width, height) {
    this.X = centerX;
    this.Y = centerY;
    
    this.cellsize = cellSize;
    this.width = width;
    this.height = height;
    
    this.GRID = [];
    
    // THESE NEEDS TO BE ASSIGNED BEFORE USE
    this.playerRef = null;
    this.pX = null;
    this.pY = null;
    
    this.buildGrid();
  }
  
  buildGrid = function() {
    // Clear the grid just in case
    this.GRID = [];
    
    // Populate the grid
    let currY = this.Y - (((this.height-1)/2) * this.cellsize);
    for(let row = 0; row < this.height; row++) {
      let temp = [];
      let currX = this.X - ((this.width/2) * this.cellsize);
      // GridCell Constructor: constructor(name, collisionType, xPos, yPos, size, floorSprite)
      for(let col = 0; col < this.width; col++) {
        temp.push(new GridCell(row + " " + col, 0, currX, currY, this.cellsize, "floortemp"));
        currX += this.cellsize;
      }
      currY += this.cellsize;
      currX = this.X - ((this.width/2) * this.cellsize);
      this.GRID.push(temp);
    }
  }
  
  // Set the player reference
  setPlayerRef = function(pl) {
    this.playerRef = pl;
    this.GRID[pl.gX][pl.gY].setItem(pl);
    this.pX = pl.gX;
    this.pY = pl.gY;
  }
  
  setItem = function(X, Y, item) {
    if((X > this.GRID.length) || (X < 0) || (Y > this.GRID[X].length) || (Y < 0)) {
      return false;
    }
    this.GRID[X][Y].setItem(item);
  }
  
  draw = function() {
    for(let row = 0; row < this.height; row++) {
      for(let col = 0; col < this.width; col++) {
        this.GRID[row][col].draw();
        // CALL DEBUG LINE: screen.drawText("|" + row + "," + col + "|", this.GRID[row][col].getX(), this.GRID[row][col].getY(), 8, ("rgb(0,0,0)"));
      }
    }
  }
  
  update = function() {
    // Update location of the player
    this.GRID[this.pX][this.pY].setItem(null);
    this.pX = this.playerRef.gX;
    this.pY = this.playerRef.gY;
    this.GRID[this.pX][this.pY].setItem(this.playerRef);
    
    // Check visibility based on player location (Set grid cell accordinly)
    for(let row = 0; row < this.height; row++) {
      for(let col = 0; col < this.width; col++) {
        let coords = {X: row, Y: col};
        this.GRID[row][col].setVisible(this.playerRef.checkVisible(coords));
      }
    }
  }
}