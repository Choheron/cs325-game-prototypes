initMenu = function() {
  starAlive = false;
  starStep = 0;
  shootingStarX = ((Math.random() * 360) - 180);
  shootingStarY = (Math.random() * 50) + 50;
  
  drawInstructions = false;
  
  optionsMenu = new options();
  currOpt = optionsMenu.getOptions();
  drawOptions = false;
  
  audio.playSound("thunder", currOpt["volume"]);
  
  music = audio.playMusic("menumusic", currOpt["volume"], 1);
  music.setVolume(currOpt["volume"]);
  
  setupMenu();
}

menuUpdate = function() {
  // Update volume of music if options are changed in menu, otherwise check for closing of option menu
  if(drawOptions) {
    optionReturn = optionsMenu.update();
    if(optionReturn >= 0 && optionReturn <=10) {
      currOpt = optionsMenu.getOptions();
      music.setVolume(currOpt["volume"]);
      optionReturn = null;
    }
    if(optionReturn == 99) {
      currOpt = optionsMenu.getOptions();
      music.setVolume(currOpt["volume"]);
      audio.playSound("uisound", currOpt["volume"]);
      drawOptions = false;
      optionReturn = null;
    } else {
      return;
    }
  }
  
  starStep++;
  
  if(keyboard.release.I && !drawInstructions ) {
    audio.playSound("uisound", currOpt["volume"]);
    drawInstructions = true;
  } else if(drawInstructions && keyboard.release.I) {
    audio.playSound("uisound", currOpt["volume"]);
    drawInstructions = false;
  }
  
  if(keyboard.press.O && !drawOptions) {
    audio.playSound("uisound", currOpt["volume"]);
    drawOptions = true;
  }
  
  if(keyboard.press.ENTER) {
    music.stop();
    return currOpt;
  }
  return null;
}

menuDraw = function() {
  if(drawOptions) {
    optionsMenu.draw();
    return;
  }
  
  setupMenu();
  if(!starAlive && starStep >= 120 && !drawInstructions && !drawOptions) {
    starAlive = true;
    starStep = 0;
    shootingStarX = ((Math.random() * 360) - 180);
    shootingStarY = (Math.random() * 50) + 50;
  } else if(starAlive) {
    sprites["shootingstar"].setFrame(starStep);
    screen.drawSprite(sprites["shootingstar"], shootingStarX, shootingStarY, 30);
    if(starStep >= 10) {
      starAlive = false;
      starStep = 0;
    }
  }

  screen.drawText("[Press \"O\" for options]", -(screen.width/2)+40, (screen.height/2)-5, 8, "rgb(255,255,255)");
  if(starStep < 30 || (starStep > 60 && starStep < 90)) {
    screen.drawText("Press \"Enter\" to start...", 0,-83, 8, "rgb(255,255,255)");
  } else {
    screen.drawText("Press \"I\" to toggle instructions...", 0,-93, 8, "rgb(255,255,255)");
  }
}

setupMenu = function() {
  screen.clear();
  screen.drawSprite("splashscreenv1", 0, 0, screen.width, screen.height);
  screen.drawText("URSA MANOR", 0,-60, 50, "rgb(255,255,255)");
  
  if(drawInstructions) {
    screen.fillRoundRect(0, 20, screen.width*(4/5), screen.height/2+10, 10,"rgba(0,0,0,0.7");
    
    screen.drawText("Welcome to \"Ursa Manor\"!", 0, ((screen.height*(3/4))/2)-10, 10, "rgb(255,255,255)");
    screen.drawText("You have been called here to banish the curse on URSA MANOR...", 0, ((screen.height*(3/4))/2)-20, 10, "rgb(255,255,255)");
    screen.drawText("To do so, drag the ghosts into the circles (nodes)", 0, ((screen.height*(3/4))/2)-30, 10, "rgb(255,255,255)");
    screen.drawText("to trap them in the constellations!", 0, ((screen.height*(3/4))/2)-40, 10, "rgb(255,255,255)");
    screen.drawText("In order to banish the curse, all nodes must be", 0, ((screen.height*(3/4))/2)-50, 10, "rgb(255,255,255)");
    screen.drawText("by a ghost at once!", 0, ((screen.height*(3/4))/2)-60, 10, "rgb(255,255,255)");
    screen.drawText("Be careful! If the ghosts touch too much, they will DIE!", 0, ((screen.height*(3/4))/2)-70, 10, "rgb(255,255,255)");
    screen.drawText("If too many ghosts die, you lose and the curse takes hold...", 0, ((screen.height*(3/4))/2)-80, 10, "rgb(255,255,255)");
    screen.drawText("NOTE: A MOUSE IS RECCOMENDED FOR THIS GAME", 0, ((screen.height*(3/4))/2)-100, 8, "rgb(255,255,255)");
  }
}





