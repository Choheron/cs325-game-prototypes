options = class {  
  constructor() {
    this.volume = 0.2;
    this.difficulty = 1;
    this.lvlCount = 3;
    
    // CONSTRUCTOR FOR BUTTON: button(name, xPos, yPos, width, height, text, textSize, textColor, baseColor, selColor, bordColor, rounded);
    // DIFFICULTY BUTTONS LIST
    this.diffButtons = [
      // button(name, xPos, yPos, width, height, text, textSize, textColor, baseColor, selColor, bordColor, rounded);
        new button("1", -50, 50, 40, 15, "EASY", 10, "rgb(0,0,0)", "rgb(188, 93, 184)", "rgb(0, 255, 0)", "rgb(0,0,0)", true),
        new button("2", 0, 50, 40, 15, "MEDIUM", 10, "rgb(0,0,0)", "rgb(188, 93, 184)", "rgb(255, 255, 0)", "rgb(0,0,0)", true),
        new button("3", 50, 50, 40, 15, "HARD", 10, "rgb(0,0,0)", "rgb(188, 93, 184)", "rgb(255, 0, 0)", "rgb(0,0,0)", true),
        new button("4", 100, 50, 40, 15, "INSANE", 10, "rgb(0,0,0)", "rgb(188, 93, 184)", "rgb(255, 112, 0)", "rgb(0,0,0)", true),
      ];
    // Set corresponding button to difficulty
    for(let i = 0; i < this.diffButtons.length; i++) {
      if(this.difficulty == parseInt(this.diffButtons[i].getName(), 10)) {
        this.diffButtons[i].setSelected(true);
      }
    }
    
    // CONSTRUCTOR FOR BUTTON: button(name, xPos, yPos, width, height, text, textSize, textColor, baseColor, selColor, bordColor, rounded);
    // VOLUME BUTTONS LIST
    this.volButtons = [
      // button(name, xPos, yPos, width, height, text, textSize, textColor, baseColor, selColor, bordColor, rounded);
        new button("0", -50, 28, 10, 15, "0", 10, "rgb(0,0,0)", "rgb(188, 93, 184)", "rgb(115, 45, 152)", "rgb(0,0,0)", true),
        new button("1", -35, 28, 10, 15, "1", 10, "rgb(0,0,0)", "rgb(188, 93, 184)", "rgb(115, 45, 152)", "rgb(0,0,0)", true),
        new button("2", -20, 28, 10, 15, "2", 10, "rgb(0,0,0)", "rgb(188, 93, 184)", "rgb(115, 45, 152)", "rgb(0,0,0)", true),
        new button("3", -5, 28, 10, 15, "3", 10, "rgb(0,0,0)", "rgb(188, 93, 184)", "rgb(115, 45, 152)", "rgb(0,0,0)", true),
        new button("4", 10, 28, 10, 15, "4", 10, "rgb(0,0,0)", "rgb(188, 93, 184)", "rgb(115, 45, 152)", "rgb(0,0,0)", true),
        new button("5", 25, 28, 10, 15, "5", 10, "rgb(0,0,0)", "rgb(188, 93, 184)", "rgb(115, 45, 152)", "rgb(0,0,0)", true),
        new button("6", 40, 28, 10, 15, "6", 10, "rgb(0,0,0)", "rgb(188, 93, 184)", "rgb(115, 45, 152)", "rgb(0,0,0)", true),
        new button("7", 55, 28, 10, 15, "7", 10, "rgb(0,0,0)", "rgb(188, 93, 184)", "rgb(115, 45, 152)", "rgb(0,0,0)", true),
        new button("8", 70, 28, 10, 15, "8", 10, "rgb(0,0,0)", "rgb(188, 93, 184)", "rgb(115, 45, 152)", "rgb(0,0,0)", true),
        new button("9", 85, 28, 10, 15, "9", 10, "rgb(0,0,0)", "rgb(188, 93, 184)", "rgb(115, 45, 152)", "rgb(0,0,0)", true),
        new button("10", 100, 28, 10, 15, "10", 10, "rgb(0,0,0)", "rgb(188, 93, 184)", "rgb(115, 45, 152)", "rgb(0,0,0)", true),
      ];
    // Set corresponding button to vol
    for(let i = 0; i < this.volButtons.length; i++) {
      if((this.volume*10) == parseInt(this.volButtons[i].getName(), 10)) {
        this.volButtons[i].setSelected(true);
      }
    }
    
    this.lvlButtons = [
      // button(name, xPos, yPos, width, height, text, textSize, textColor, baseColor, selColor, bordColor, rounded);
        new button("2", -20, 6, 10, 15, "2", 10, "rgb(0,0,0)", "rgb(188, 93, 184)", "rgb(115, 45, 152)", "rgb(0,0,0)", true),
        new button("3", -5, 6, 10, 15, "3", 10, "rgb(0,0,0)", "rgb(188, 93, 184)", "rgb(115, 45, 152)", "rgb(0,0,0)", true),
        new button("4", 10, 6, 10, 15, "4", 10, "rgb(0,0,0)", "rgb(188, 93, 184)", "rgb(115, 45, 152)", "rgb(0,0,0)", true),
        new button("5", 25, 6, 10, 15, "5", 10, "rgb(0,0,0)", "rgb(188, 93, 184)", "rgb(115, 45, 152)", "rgb(0,0,0)", true)
      ];
    // Set corresponding button to lvl
    for(let i = 0; i < this.lvlButtons.length; i++) {
      if((this.lvlCount) == parseInt(this.lvlButtons[i].getName(), 10)) {
        this.lvlButtons[i].setSelected(true);
      }
    }
    
    
  }
  
  
  update = function() {
    // Update difficulty buttons and set difficulty if clicked
    for(let i = 0; i < this.diffButtons.length; i++) {
      let toggled = this.diffButtons[i].update();
      if(toggled != null) {
        print("OPTIONS: Difficulty button " + toggled + " selected, New Value: " + this.diffButtons[i].getName());
        this.updateList(this.intFromName(toggled, 10)-1, this.diffButtons);
        this.difficulty = this.intFromName(toggled, 10);
        audio.playSound("uisound", this.volume);
        toggled = null;
      }
    }
    
    // Update volume buttons and set volume if clicked
    for(let i = 0; i < this.volButtons.length; i++) {
      let toggled = this.volButtons[i].update();
      if(toggled != null) {
        print("OPTIONS: Volume button " + toggled + " selected, New Value: " + this.volButtons[i].getName());
        this.updateList(this.intFromName(toggled, 10), this.volButtons);
        this.volume = this.intFromName(toggled, 10)/10;
        audio.playSound("uisound", this.volume);
        toggled = null;
        return this.volume;
      }
    }
    
    // Update level buttons and set level if clicked
    for(let i = 0; i < this.lvlButtons.length; i++) {
      let toggled = this.lvlButtons[i].update();
      if(toggled != null) {
        print("OPTIONS: Level button " + toggled + " selected, New Value: " + this.lvlButtons[i].getName());
        this.lvlCount = this.intFromName(toggled, 10);
        this.updateList(this.lvlCount-2, this.lvlButtons);
        audio.playSound("uisound", this.volume);
        toggled = null;
      }
    }
    
    // Close options with use of 'ESCAPE'
    if(keyboard.press.ESCAPE) {
      return 99;
    }
  }
  
  
  // Toggle all buttons NOT AT THE PASSED IN INDEX off, in the passed in list.
  updateList = function(index, list) {
    for(let i = 0; i < list.length; i++) {
      if(i == index) {
        continue;
      }
      list[i].setSelected(false);
    }
  }
  
  
  draw = function() {
    screen.clear();
    screen.drawSprite("splashscreenv1", 0, 0, screen.width, screen.height);
    
    // Draw box to hold options
    screen.fillRoundRect(0, 0, screen.width*(4/5), screen.height*(4/5), 10,"rgb(162, 0, 212)");
    screen.drawRoundRect(0, 0, screen.width*(4/5), screen.height*(4/5), 10,"rgb(0, 0, 0)");
    
    screen.drawText("OPTIONS", 0, screen.height*(4/5)/2+10, 15, "rgb(255,255,255)");
    screen.drawText("Press \"ESCAPE\" to save and close...", 0, (screen.height*(4/5)/2)-10, 8, "rgb(255,255,255)");
    
    // Setting Box -- DIFFICULTY
    screen.drawRoundRect(0, 50, screen.width*(7/10), 20, 5, "rgb(0, 0, 0)");
    screen.drawText("Difficuty:", -((screen.width*(4/5))/2)+40, 50, 10, "rgb(255,255,255)");
    // Draw DIFFICULTY Buttons
    for(let i = 0; i < this.diffButtons.length; i++) {
      this.diffButtons[i].draw();
    }
    
    // Setting Box -- VOLUME
    screen.drawRoundRect(0, 28, screen.width*(7/10), 20, 5, "rgb(0, 0, 0)");
    screen.drawText("Volume:", -((screen.width*(4/5))/2)+40, 28, 10, "rgb(255,255,255)");
    // Draw VOLUME Buttons
    for(let i = 0; i < this.volButtons.length; i++) {
      this.volButtons[i].draw();
    }
    
    // Setting Box -- LEVEL COUNT
    screen.drawRoundRect(0, 6, screen.width*(7/10), 20, 5, "rgb(0, 0, 0)");
    screen.drawText("Level Count:", -((screen.width*(4/5))/2)+47, 6, 10, "rgb(255,255,255)");
    // Draw LEVEL COUNT Buttons
    for(let i = 0; i < this.lvlButtons.length; i++) {
      this.lvlButtons[i].draw();
    }
  }
  
  
  getOptions = function() {
    let out = [];
    out.difficulty = this.difficulty;
    out.volume = this.volume;
    out.levelCount = this.lvlCount;
    return out;
  }
  
  
  // Get int from string (name) - Needed because parseInt is falsey
  intFromName = function(name, base) {
    let parsed = parseInt(name, base);
    return Number.isNaN(parsed) ? 0 : parsed;
  }
}












