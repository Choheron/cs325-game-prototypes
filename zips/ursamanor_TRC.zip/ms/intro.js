initIntro = function() {
  print("Introduction Initalized...");
  print("Starting intro music...");
  // Play intro music at default 0.2 volume.
  introMusic = audio.playMusic("intromusic", 0.2, 1);
  // Ensure volume is set lower
  introMusic.setVolume(0.2);
  
  introText = [];
  introText.push(["*YOU APPROACH THE MANOR*","*AS YOU APPROACH THE DOOR SWINGS OPEN SLOWLY*","*IN THE DOORWAY IS AN OLD MAN WEARING A BEAR SKIN*","*HE SMILES AT YOU AND SPEAKS*"]);
  introText.push("Oh... You're here!");
  introText.push(["I wasn't expecting you so soon...","You'll have to forgive me for being in my formal wear!"]);
  introText.push(["Why yes, my formal attire IS a bear skin...","It belonged to my great grandfather...", "...my great grandmother skinned him herself..."]);
  introText.push(["Anyway...", "I'm not sure if your boss told you the situation...", "My name is Abraham Ursa."]);
  introText.push("I am the last surviving member of the noble Ursa family...");
  introText.push("Oh... Right... You just want to know about the job");
  introText.push(["The great constellation,", "URSA MAJOR","is DIRECTLY over the manor!", "Naturally that can only mean one thing..."]);
  introText.push("...the ghosts are back...");
  introText.push("...obviously...");
  introText.push(["So!", "Get rid of them before the night is out", "or the curse of the bear will take hold..."]);
  introText.push(["Good luck", "","and welcome to..."]);
  introStep = 0;
  
  screen.clear();
  nextDialog();
}

introUpdate = function() {
  if(touch.press) {
    introStep++;
    return nextDialog();
  }
  
  if(keyboard.ESCAPE) {
    // Stop intro music
    introMusic.stop();
    return 1;
  }
}

// Intro dialog handler
nextDialog = function() {
  screen.clear();
  screen.setColor("rgb(255,255,255)");
  
  if(introStep == (introText.length)) {
    // Stop intro music
    introMusic.stop();
    // Activate title screen
    return 1;
  } else if(Array.isArray(introText[introStep])) {
    yVal = ((introText[introStep].length * 10)/2);
    for(let i = 0; i < introText[introStep].length; i++) {
      screen.drawText(introText[introStep][i], 0, yVal, 10);
      yVal -= 10;
    }
  } else {
    screen.drawText(introText[introStep], 0, 0, 10);
  }
  // Draw "Click to Continue" Text
  screen.drawText("Click to Continue...", 0, -50, 5);
  screen.drawText("Press 'ESC' to Skip...", 0, -55, 5);
  return null;
}