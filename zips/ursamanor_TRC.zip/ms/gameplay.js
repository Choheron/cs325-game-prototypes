gameplay = class {
  init = function(options) {
    print("Gameplay Initalized...");
    
    // Amount of levels for the user to beat!
    this.levelCount = options["levelCount"];
    // Current level
    this.currLevel = 1;
    
    // Constellation Parameters
    this.nodeSize = 25;
    this.ghostSize = 20;
    this.ghostHP = 4;
    this.volume = options["volume"];
    
    this.difficulty = options["difficulty"];
    switch(this.difficulty) {
      case 1:
        this.ghostSpeed = 0.125; // EASY
        break;
      case 2:
        this.ghostSpeed = 0.25; // MEDIUM
        break;
      case 3:
        this.ghostSpeed = 0.5; // HARD
        break;
      case 4:
        this.ghostSpeed = 1; // INSANE
        break;
    }
    
    // Begin gameplay music
    print("Beginning gameplay music (if not muted)...");
    if(this.volume != 0) {
      this.gPlayMusic = audio.playMusic("gameplaymusic", this.volume, 1);
      this.gPlayMusic.setVolume(this.volume);
    }
    
    // Constel Parameters: Coordinate List [X,Y], Node Size, Ghost Size, Ghost Health, Ghost Speed, Volume
    this.currList = this.generateCoords(this.currLevel + 2);
    this.currConst = new constel(this.currList, this.nodeSize, this.ghostSize, this.ghostHP, this.ghostSpeed, this.volume);
  }
  
  generateCoords = function(level) {
    let out = [];
    for(var i = 0; i < level; i++) {
      do {
        this.widthCalc = screen.width - (this.nodeSize*2);
        this.heightCalc = screen.height - (this.nodeSize*2);
        this.xPos = Math.round(((Math.floor((Math.random() * this.widthCalc)) - (this.widthCalc/2))/this.nodeSize))*this.nodeSize;
        this.yPos = Math.round(((Math.floor((Math.random() * this.heightCalc)) - (this.heightCalc/2))/this.nodeSize))*this.nodeSize;
      } while(out.indexOf(this.xPos, 2) != -1 || out.indexOf(this.yPos, 2) != -1);
      out.push(this.xPos);
      out.push(this.yPos);
    }
    print(out.toString());
    return out;
  }
  
  update = function() {
    let levelComp = this.currConst.update();
    if(levelComp == 1) {
      print("LEVEL COMPLETE: Finished level " + this.currLevel + '...')
      if(this.currLevel == this.levelCount) {
        this.gPlayMusic.stop();
        // End Game after levels are completed
        return 1; 
      }
      this.nextLevel();
    } else if(levelComp == 2) {
      this.gPlayMusic.stop();
      return 2;
    }
  }
  
  nextLevel = function() {
    this.currLevel++;
    
    this.currList = this.generateCoords(this.currLevel + 2);
    this.currConst = new constel(this.currList, this.nodeSize, this.ghostSize, this.ghostHP, this.ghostSpeed, this.volume);
  }
  
  
  draw = function() {
    this.currConst.draw();
  }
}
