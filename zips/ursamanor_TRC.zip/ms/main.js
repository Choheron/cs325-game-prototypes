init = function() {
  gamestage = 1;
  
  gameObj = new gameplay();
  dummyOptions = new options();
  dummyButton = new button();
}

update = function() {
  switch(gamestage) {
    case 1:
      print("Entering Introduction...");
      initIntro();
      gamestage++;
      break;
    case 2:
      menuCheck = introUpdate();
      if(menuCheck != null) {
        print("Entering Menu Stage...");
        gamestage++;
        // Initalize menu before entering menu stage
        initMenu();
      }
      break;
    case 3:
      beginOptions = menuUpdate();
      if(beginOptions != null) {
        print("Entering Gameplay Stage...");
        gamestage++;
        // Initalize gameplay state
        gameObj.init(beginOptions);
      }
      break;
    case 4:
      screen.clear();
      gameplayCheck = gameObj.update();
      if(gameplayCheck == 1) {
        print("Entering Final Screen...");
        gamestage++;
      } else if(gameplayCheck == 2) {
        init();
      }
      break;
    case 5:
      if(keyboard.press.ENTER || keyboard.press.SPACE || touch.press) {
        print("Restarting...");
        init();
      }
      break;
  }
}

draw = function() {
  if(gamestage == 3) {
    menuDraw();
  } else if(gamestage == 4) {
    gameObj.draw();
  } else if(gamestage == 5) {
    
    screen.clear();
    screen.drawSprite("splashscreenv1", 0, 0, screen.width, screen.height);
    screen.drawText("Congratulations!!! You have sucessfully removed the curse of", 0,-40, 10, "rgb(255,255,255)");
    screen.drawText("URSA MANOR", 0,-60, 50, "rgb(255,255,255)");
    screen.drawText("Click or Press 'Enter'/'Space' to restart...", 0,-85, 8, "rgb(255,255,255)");
    
  }
}