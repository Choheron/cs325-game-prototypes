constel = class {
  constructor(coordList, nodeSize, ghostSize, ghostHealth, ghostSpeed, volume) {
    this.nodeSize = nodeSize;
    this.nodeCount = 0;
    this.coordList = coordList;
    this.nodeList = [];
    this.ghostList = [];
    
    this.winner = false;
    this.loser = false;
    
    this.ghostSize = ghostSize;
    this.ghostHealth = ghostHealth;
    this.ghostSpeed = ghostSpeed;
    
    this.dragging = false;
    this.currGhost = null;
    
    this.startTime = new Date();
    this.endTime = null;
    
    this.volume = volume;
    
    this.buildScene();
  }
  
  
  // Construct the nodes and ghosts
  buildScene = function() {
    // Node Parameters: X, Y, Size
    for(let i = 0; i < (this.coordList.length); i += 2) {
      this.nodeList.push(new this.Node(this.coordList[i], this.coordList[i+1], this.nodeSize));
      print("Building Node " + i/2 + "...");
    }
    this.nodeCount = this.nodeList.length;
    
    // Ghost Parameters: Width, Height, X, Y, HP, Movespeed
    for(let i = 0; i < this.nodeCount + 2; i++) {
      let ghostX = ((Math.floor(Math.random() * screen.width)) - screen.width/2);
      let ghostY = ((Math.floor(Math.random() * screen.height)) - screen.height/2);
      this.ghostList.push(new ghost(this.ghostSize, this.ghostSize, ghostX, ghostY, this.ghostHealth, this.ghostSpeed));
    }
  }
  
  
  // Count the number of alive ghosts
  aliveCount = function() {
    let count = 0;
    for(var i = 0; i < this.ghostList.length; i++) {
      if(this.ghostList[i].isAlive()) {
        count++;
      }
    }
    return count;
  }
  
  
  // Constel update function
  update = function() {
    // Only update game if user has not won or lost
    if((this.winner == false) && (this.loser == false)) {
      if(this.checkNodes()) {
        this.winner = true;
        this.endTime = new Date();
        return;
      }
      
      if((this.aliveCount() < this.nodeCount) && (this.winner == false)) {
        if(this.volume != 0) {
          audio.playSound("gameover", this.volume);
        }
        this.loser = true;
      }
      
      if(mouse.release && this.dragging) {
        this.dragging = false;
        this.currGhost = null;
      }
      
      // Run Ghost Update Function
      for(var i = 0; i < this.ghostList.length; i++) {
        this.ghostList[i].update();
      }
      
      // Run Node Update Function - Requires ghostlist to be passed in.
      for(let i = 0; i < this.nodeCount; i++) {
        this.nodeList[i].update(this.ghostList);
      }
      
      if(this.dragging) {
        this.currGhost.drag(this.dragging, this.currGhost);
      }
      
      if(touch.press) {
        for(var i = 0; i < this.ghostList.length; i++) {
          // Check if ghost is alive and then if the user has clicked on them
          if(this.ghostList[i].isAlive() && this.ghostList[i].checkHit(touch.x, touch.y)) {
            this.dragging = true;
            this.currGhost = this.ghostList[i];
          }
        }
      }
      
      for(var i = 0; i < this.ghostList.length; i++) {
        for(var j = i+1; j < this.ghostList.length; j++) {
          if(this.ghostList[i].testCollision(this.ghostList[j])) {
            if(this.volume != 0) {
              audio.playSound("deathsound", this.volume);
            }
          }
        }
      }
      
      // Reassign goals if ghost is not on goal cooldown
      for(var i = 0; i < this.ghostList.length; i++) {
        if(!this.ghostList[i].isOnGoalCooldown()) {
          this.assignGoal(this.ghostList[i]);
        }
      }
      
      // Return null to stop moving level foreward
      return null;
      
    } else if(this.winner) {
      // Move level foreward
      if(keyboard.press.ENTER || keyboard.press.SPACE || touch.press) {
        if(this.volume != 0) {
          audio.playSound("uisound", this.volume);
        }
        return 1;
      }
      
    } else {
      // Restart the system
      if(keyboard.press.ENTER || keyboard.press.SPACE || touch.press) {
        if(this.volume != 0) {
          audio.playSound("uisound", this.volume);
        }
        print("Initiating Start Over Process...")
        return 2;
      }
    }
  }
  
  
  // Set goal for passed in Ghost
  assignGoal = function(ghost) {
    let ghostX = Math.round((Math.floor(Math.random() * screen.width)) - screen.width/2);
    let ghostY = Math.round((Math.floor(Math.random() * screen.height)) - screen.height/2);
    ghost.setGoal(ghostX, ghostY);
  }
  
  // Check nodes for ghosts over them, return true once all nodes have a ghost over them 
  checkNodes = function() {
    let temp = true
    for(let i = 0; i < this.nodeList.length; i++) {
      for(let j = 0; j < this.ghostList.length; j++) {
        if(!this.nodeList[i].underGhost(this.ghostList[j])) {
          temp = false;
        } else {
          temp = true;
          break;
        }
      }
      if(temp == false) {
        return false;
      }
    }
    return temp;
  }
  
  
  // Constel draw function
  draw = function() {
    if(this.winner) {
      // Draw loss screen if player wins
      this.drawWin();
    } else if(this.loser) {
      // Draw loss screen if player loses
      this.drawLoss();
    } else {
      // Draw Normal Backdrop
      screen.drawSprite("moonbackdrop", 0, 0, screen.width, screen.height);
      
      this.drawUI();
      
      for(let i = 0; i < this.nodeCount; i++) {
        this.nodeList[i].draw();
      }
      
      for(let i = 0; i < this.ghostList.length; i++) {
        this.ghostList[i].draw();
      }
    }
  }
  
  
  // Draw UI helper function
  drawUI = function() {
    screen.fillRect(0, -((screen.height/2)-5), screen.width, 12, "rgb(0,0,0)")
    
    screen.drawText("Level: " + (this.nodeCount-2), -(screen.width*(4/5))/2, -((screen.height/2)-6), 10, "rgb(255,255,255)");
    
    let curseLevel = ((100/this.ghostList.length) * this.aliveCount());
    screen.drawText("Curse Level: " + curseLevel.toFixed(2) + "%", 20, -((screen.height/2)-6), 10, "rgb(255,255,255)");
    
    let difficulty = "ERR";
    switch(this.ghostSpeed) {
      case 0.125:
        difficulty = "EASY";
        break;
      case 0.2:
        difficulty = "MEDIUM";
        break;
      case 0.5:
        difficulty = "HARD";
        break;
      case 1:
        difficulty = "INSANE";
        break;
    }
    screen.drawText("Difficulty: " + difficulty, -80, -((screen.height/2)-6), 10, "rgb(255,255,255)");
    screen.drawText("Ghosts Alive: " + this.aliveCount(), (((screen.width*(4/5))/2)-10), -((screen.height/2)-6), 10, "rgb(255,255,255)");
  }
  
  // Draw Win Screen
  drawWin = function() {
    // Draw Normal Backdrop
    screen.drawSprite("moonbackdrop", 0, 0, screen.width, screen.height);
    
    for(let i = 0; i < this.nodeCount-1; i++) {
      let temp = [this.nodeList[i].getXY()[0],this.nodeList[i].getXY()[1],this.nodeList[i+1].getXY()[0],this.nodeList[i+1].getXY()[1]];
      screen.drawLine(temp[0],temp[1],temp[2],temp[3], "rgba(223, 210, 31, 0.5)");
    }
    
    for(let i = 0; i < this.nodeCount; i++) {
      this.nodeList[i].drawEndSpecial();
    }
    
    screen.fillRoundRect(0, 0, screen.width*(4/5), 50, screen.width*(1/20), "rgba(0,0,0,0.7)")
    screen.drawText("You have banished the curse in this room!", 0, (50/4), (screen.height*(1/15)), "rgb(255,255,255)");
    screen.drawText("Level: " + (this.nodeCount-2) + ", Time: " + (Math.abs(this.startTime - this.endTime)/1000) + " seconds!", 0, 0, (screen.height*(1/20)), "rgb(255,255,255)");
    screen.drawText("Press 'Enter' or 'Space' to start the next level...", 0, -(50/4), (screen.height*(1/20)), "rgb(255,255,255)");
  }
  
  // Draw Loss Screen
  drawLoss = function() {
    // Draw crumbling castle backdrop
    screen.drawSprite("splashscreenv1updown", 0, 0, screen.width, -screen.height);
    
    screen.fillRect(0, 0, screen.width, screen.height, "rgba(255, 0, 0, 0.6)")
    
    screen.drawText("You failed to protect", 0,-40, 10, "rgb(255,255,255)");
    screen.drawText("URSA MANOR", 0,-60, 50, "rgb(255,255,255)");
    screen.drawText("Press 'Enter' or 'Space' to restart...", 0,-85, 8, "rgb(255,255,255)");
  }
  
  
  // Nested class to define a node
  Node = class {
    constructor(xPos, yPos, size) {
      this.size = size;
      this.xPos = xPos;
      this.yPos = yPos;
      this.under = false;
    }
    
    // Return the coordinates of the node
    getXY = function() {
      return [this.xPos, this.yPos];
    }
    
    // Update to check if under ghost
    update = function(ghostList) {
      for(let i = 0; i < ghostList.length; i++) {
        if(this.underGhost(ghostList[i])) {
          this.under = true;
          return;
        }
      }
      this.under = false;
    }
    
    // Return the status of a specific ghost being over said node
    underGhost = function(ghostObj) {
      if(!ghostObj.isAlive()) {
        return false;
      }
      if((Math.abs(this.xPos - ghostObj.xPos) <= (this.size/2)) &&
         (Math.abs(this.yPos - ghostObj.yPos) <= (this.size/2))) {
        return true;
      }
      return false;
    }
    
    drawEndSpecial = function() {
      screen.setRadialGradient(this.xPos, this.yPos, this.size, "rgba(223, 210, 31, 1)", "rgba(175, 168, 76, 0.0)")
      screen.fillRound(this.xPos, this.yPos, this.size*2, this.size*2);
    }
    
    // Node Draw function
    draw = function() {
      if(this.under == true) {
        screen.setRadialGradient(this.xPos, this.yPos, this.size, "rgba(223, 210, 31, 1)", "rgba(175, 168, 76, 0.51)")
        screen.fillRound(this.xPos, this.yPos, this.size, this.size);
        screen.drawRound(this.xPos, this.yPos, this.size, this.size, "rgba(255, 229, 35, 0.5)");
      } else {
        screen.drawRound(this.xPos, this.yPos, this.size, this.size, "rgba(245, 96, 66, 0.5)");  
      }
      
    }
  }
}







