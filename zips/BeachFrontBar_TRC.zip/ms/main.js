init = function() {
  // Declare inital asset list for transfer
  assetList = [];
  // Declare item lists
  primitives = [];
  craftables = [];
  // Initalize loading of items
  loadAssets();
  
  // Set to true once inital load of assets have taken place
  ready = false;
  loaded = false;
  
  // Initalize inventory
  // constructor(size, stack, autoOrganize, bgColor, cellColor, cellBorderColor, itemTxtColor, rounded)
  i = new Inventory(30, true, true, "rgb(157, 156, 109)", "rgb(200,200,200)", "rgb(0,0,0)", "rgb(0,0,0)", true);
  // Handle inventory display state
  showInv = false;
  
  // Initalize background map reference
  bgMap = maps["map2"];
  
  // Initalize reference to MAIN map
  map = maps["map1"];
  
  // Initalize map collision skeleton
  // constructor(width, height, cellSize)
  collide = new WallCollision(32, 18, (screen.width/32), map);
  
  // Initalize new player
  // constructor(startX, startY, sprite, width, height, colliderClass)
  player = new Player(0, 0, "player", (screen.width/32)+5, (screen.width/32)+5, collide);
  
  // Intialize crafting class - Set lists after they have been loaded
  cMenu = new Crafting([], [], i);
  // Handle crafting display state
  showCraft = false;
  
  // Initalize instructions
  inst = new Instructions(true);
  // Handle Instructions Display State
  showInst = false;
  
  // Debug variable for testing
  debug = false;
  
  // Current goal item
  currGoal = null;
  sold = false;
}


update = function() {
  // Return if assets are not loaded
  if(!assetList) {
    return;
    // If the assets are available but the lists arent loaded, load them
  } else if(assetList && !loaded && ready) {
    primitives = assetList[0];
    craftables = assetList[1];
    
    cMenu.setLists(primitives, craftables);
    
    loaded = true;
  }
  
  // Update Inventory
  i.update();
  
  // Update Player
  player.update();
  
  // Interact with areas if the user attempts to interact
  if(keyboard.press.E) {
    interact();
  }
  
  if(showCraft) {
    cMenu.update();
    
    if(keyboard.press.I || keyboard.press.ESCAPE) {
      showCraft = false;
      return;
    }
  }
  
  // Toggle instructions
  if(keyboard.press.H ) {
    showInst = !showInst;
  }
  // Turn off instructions if they are on using escape
  if(showInst && keyboard.press.ESCAPE) {
    showInst = false;
    return;
  }
  
  if(keyboard.SHIFT && keyboard.press.F1) {
    debug = !debug;
  }
  if(keyboard.press.I || keyboard.press.ESCAPE) {
    showInv = !showInv;
  }
  
  if(currGoal == null && loaded == true) {
    let rand = Math.floor(Math.random() * 2);
    if(rand == 0) {
      rand = Math.floor(Math.random() * craftables.length);
      currGoal = craftables[rand];
    } else {
      rand = Math.floor(Math.random() * primitives.length);
      currGoal = primitives[rand];
    }
  }
}


draw = function() {
  // Return if assets are not loaded
  if(!assetList) {
    screen.drawText("LOADING GAME...", 0, 0, screen.height/10, "rgb(255, 255, 255");
  }
  
  // Draw Background Map
  screen.drawMap("map2", 0, 0, screen.width, screen.height)
  // Draw Base Map
  screen.drawMap("map1", 0, 0, screen.width, screen.height)
  
  
  // Draw Top Left UI
  screen.fillRoundRect(-(screen.width/2) + 30, (screen.height/2 - 10), 
                       80, 25, 5, "rgba(255, 255, 255, 0.5)");
  screen.drawText("Inv: 'I' or 'ESC'", -(screen.width/2) + 30,
                  (screen.height/2 - 5), 10, "rgb(0, 0, 0)");
  screen.drawText("Balance: $" + player.checkBal(), -(screen.width/2) + 30,
                  (screen.height/2 - 15), 10, "rgb(0, 0, 0)");
  // Draw Top Right UI                
  screen.fillRoundRect((screen.width/2) - 30, (screen.height/2 - 5), 
                       80, 15, 5, "rgba(255, 255, 255, 0.5)");
  screen.drawText("Help: 'H'", (screen.width/2) - 30,
                  (screen.height/2 - 5), 10, "rgb(0, 0, 0)");
                       
  // Draw Player
  player.draw();
  
  // Draw debug information if toggled
  if(debug) {
    collide.draw(player);  
  }
  
  // Draw NPC
  screen.drawSprite("player", 85, -42.5, (screen.width/32) + 2.5, (screen.width/32) + 2.5);
  // Draw blank background
  screen.drawSprite("popupblank", 85, -20, 40, 40);
  // Draw Goal Item
  if(currGoal != null) {
    screen.drawSprite(currGoal.getSprite(), 85, -18, 25, 25);
  }
  
  // Draw Inventory if toggled on
  if(showInv) {
    i.draw();
  }
  
  // Draw Instructions if toggled on
  if(showInst) {
    inst.draw();
  }
  
  // Draw crafting menu if toggled on
  if(showCraft) {
    cMenu.draw();
  }
}

interact = function() {
  let type = collide.checkInteract(player);
  
  // Check for register interaction
  if(type == "REGISTER") {
    if(i.findItem(currGoal) != -1) {
      i.removeItem(currGoal);
      player.earn(Math.floor(Math.random() * 50));
      currGoal = null;
    }
    return;
  }
  // Check for trashcan interaction
  if(type == "TRASH") {
    i.delete = true;
    showInv = true;
    return;
  }
  // Check for oven interaction
  if(type == "OVEN") {
    showCraft = true;
    return;
  }
  if(type != "") {
    i.addItem(findItem(type));
    player.setPickup(findItem(type));
  }
}

findItem = function(name) {
  for(let i = 0; i < primitives.length; i++) {
    if(primitives[i].getName().toUpperCase() == name.toUpperCase()) {
      return primitives[i];
    }
  }
}

// Load assets and wait for them to be ready
loadAssets = function() {
  asset_manager.loadJSON("items", function(data) {
    // Item Constructor:
    // constructor(name, sprite, ID, recipe)
    
    // Store item versions of primitives
    let temp = [];
    for(let i = 0; i < data["primitives"].length; i++) {
      temp.push(new Item(data["primitives"][i]["name"], data["primitives"][i]["sprite"], data["primitives"][i]["ID"], data["primitives"][i]["recipe"]));
    }
    assetList.push(temp);
    
    // Store Item versions of craftables
    temp = [];
    for(let i = 0; i < data["craftables"].length; i++) {
      temp.push(new Item(data["craftables"][i]["name"], data["craftables"][i]["sprite"], data["craftables"][i]["ID"], data["craftables"][i]["recipe"]));
    }
    assetList.push(temp);
    
    ready = true;
  });
}








































