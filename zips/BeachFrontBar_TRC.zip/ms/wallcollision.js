WallCollision = class {
  constructor(width, height, cellSize, map) {
    this.width = width;
    this.height = height;
    this.cellSize = cellSize;
    this.ref = map;
    
    this.map = [];
    this.buildMap();
  }
  
  
  buildMap = function() {
    // Fill map with inital empty values 
    for(let i = 0; i < this.height; i++) {
      let temp = [];
      for(let j = 0; j < this.width; j++) {
        // Set values depending on sprite in map
        // NOTE map.get USES ORIGIN AT BOTTOM LEFT NOT TOP LEFT
        if(this.ref.get(j, i).indexOf("wall") != -1 ||
           this.ref.get(j, i).indexOf("crate") != -1 ||
           this.ref.get(j, i).indexOf("fence") != -1 ||
           this.ref.get(j, i).indexOf("shelf") != -1 ||
           this.ref.get(j, i).indexOf("trashcan") != -1 ||
           this.ref.get(j, i).indexOf("freezer") != -1||
           this.ref.get(j, i).indexOf("palm") != -1 ||
           this.ref.get(j, i).indexOf("sink") != -1 ||
           this.ref.get(j, i).indexOf("counter") != -1 ||
           this.ref.get(j, i).indexOf("fridge") != -1 ||
           this.ref.get(j, i).indexOf("register") != -1 ||
           this.ref.get(j, i).indexOf("oven") != -1) {
          temp.push(1);
        } else {
          temp.push(0);  
        }
      }
      this.map.push(temp);
    }
  }
  
  
  set = function(x, y, val) {
    this.map[y][x] = val;
  }
  
  peek = function(x, y) {
    return this.map[y][x];
  }
  
  // Check if the player is colliding with an object
  checkCollide = function(player) {
    // Return true if the user will be out of the map
    if(player.Y < -(screen.height/2) || player.Y > (screen.height/2) ||
       player.X < -(screen.width/2) || player.X > (screen.width/2)) {
      return true; 
    }
    
    // Find the cell that the player is currently in
    let pos = this.worldToGrid(player);
    
    // Return true if the user will be colliding with a wall
    let out = false;
    if(this.peek(pos['X'], pos['Y']) == 1) {
      return true;
    }
    
    return false;
  }
  
  
  // Checks the surrounding 4 tiles for interactable objects, has the following bias:
  // TOP, BOTTOM, RIGHT, LEFT
  checkInteract = function(player) {
    let loc = this.worldToGrid(player);
    
    if(this.findInteractable(loc["X"], loc["Y"] + 1) != "") {
      return this.findInteractable(loc["X"], loc["Y"] + 1);
    }
    if(this.findInteractable(loc["X"], loc["Y"] - 1) != "") {
      return this.findInteractable(loc["X"], loc["Y"] - 1);
    }
    if(this.findInteractable(loc["X"] + 1, loc["Y"]) != "") {
      return this.findInteractable(loc["X"] + 1, loc["Y"]);
    }
    if(this.findInteractable(loc["X"] - 1, loc["Y"]) != "") {
      return this.findInteractable(loc["X"] - 1, loc["Y"]);
    }
    return "";
  }
  
  
  // Return if a cell is an interactable by stating what item it returns
  // Used for all interactable items by checking sprites
  // There is def a better way to do this -- but time limits are time limits
  findInteractable = function(x, y) {
    let cellSprite = this.ref.get(x,y);
    
    if(cellSprite == "butterfridge") {
      return "butter";
    } else if(cellSprite == "sink") {
      return "water"; 
    } else if(cellSprite.indexOf("coconut") != -1) {
      return "coconut";
    } else if(cellSprite.indexOf("banana") != -1) {
      return "banana";
    } else if(cellSprite.indexOf("chicken") != -1) {
      return "chicken";
    } else if(cellSprite.indexOf("ice") != -1) {
      return "ice";
    } else if(cellSprite.indexOf("bread") != -1) {
      return "bread";
    } else if(cellSprite.indexOf("trashcan") != -1) {
      return "TRASH";
    } else if(cellSprite.indexOf("register") != -1) {
      return "REGISTER";
    } else if(cellSprite.indexOf("oven") != -1) {
      return "OVEN";
    }
    
    return "";
  }
  
  
  // Return the grid X and Y coordinate of the player
  worldToGrid = function(player) {
    let xCell = Math.floor((player.X + screen.width/2) / (screen.width/32));
    let yCell = Math.floor((player.Y + screen.height/2) / (screen.height/18));
    
    return {X: xCell, Y: yCell};
  }
  
  
  // FOR DEBUGGING
  draw = function(player) {
    let currX = -(screen.width/2) + (this.cellSize/2);
    let currY = (screen.height/2) - (this.cellSize/2);
    
    for(let i = 0; i < 18; i++) {
      for(let j = 0; j < 32; j++) {
        let col = "rgb(255, 0, 0)";
        if(this.worldToGrid(player)["X"] == j && this.worldToGrid(player)["Y"] == this.height - (i + 1)) {
          col = "rgb(0, 255, 0)";
          screen.fillRect(currX, currY, this.cellSize, this.cellSize, "rgba(0, 255, 0, 0.5)");
        }
        screen.drawText(this.map[17 - i][j], currX, currY, 10, col);
        currX += this.cellSize;
      }
      currX = -(screen.width/2) + (this.cellSize/2);
      currY -= this.cellSize;
    }
  }
}






















