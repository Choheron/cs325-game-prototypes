Item = class {
  // Params:
  // - String name (Name of Item)
  // - String sprite (name of sprite corresponding to item)
  // - int ID
  // - List recipe [special syntax needed see comments below]
  constructor(name, sprite, ID, recipe) {
    this.name = name;
    this.sprite = sprite;
    this.ID = ID;
    
    // If a recipe (a list of items and their quantities) is provided, store it
    // Recipe Example:
    //  {{item: ITEM1, amt: XX}, {item: ITEM2, amt: XX}}
    this.recipe = null;
    if(recipe != null) {
      this.recipe = recipe;
    }
  }
  
  // Check if the item is primitive (has a recipe)
  hasRecipe = function() {
    if(this.recipe == null) {
      return false;
    }
    return true;
  }
  
  // Return the recipe list for this item
  getRecipe = function() {
    return this.recipe;
  }
  
  // Draw the items sprite, provided X, Y, Width, and Height
  draw = function(xPos, yPos, width, height) {
    screen.drawSprite(this.sprite, xPos, yPos, width, height);
  }
  
  // Return name of item
  getName = function() {
    return this.name;
  }
  
  // Set name of item to passed in string
  setName = function(newName) {
    this.name = newName;
  }
  
  // Return sprite string
  getSprite = function() {
    return this.sprite;
  }
  
  // Set sprite of item to passed in string
  setName = function(newSprite) {
    this.sprite = newSprite;
  }
  
  toString = function(debug) {
    if(debug) {
      let out = "";
      out += "\nItem Name: " + this.name;
      out += "\nItem Sprite: " + this.sprite;
      out += "\nItem ID: " + this.ID;
      out += "\nItem Recipe: " + this.recipe;
      
      return out;
    }
    return ("Name: " + this.name);
  }
}