Instructions = class {
  constructor(rounded) {
    this.rounded = rounded;
  }
  
  draw = function() {
    if(this.rounded) {
      screen.fillRoundRect(0, 0, screen.width*(4/5), screen.height*(4/5), 10, "rgba(0 , 0, 0, 0.9)");
      screen.drawText("Welcome to Beachfront Bar!", 0, screen.height*(4/5)/2-10, 15, "rgb(255,255,255)");
      
      // Instructions for picking up items
      screen.drawText("Pick up items from the crates using 'E'!", -50, screen.height*(4/5)/2 - 25, 10, "rgb(255,255,255)");
      
      screen.drawSprite("bananacrate", -100,  screen.height*(4/5)/2 - 45, 20, 20);
      screen.drawSprite("coconutcrate", -70,  screen.height*(4/5)/2 - 45, 20, 20);
      screen.drawSprite("breadcrate", -40,  screen.height*(4/5)/2 - 45, 20, 20);
      screen.drawSprite("chickencrate", -10,  screen.height*(4/5)/2 - 45, 20, 20);
      screen.drawSprite("icefreezer", 20,  screen.height*(4/5)/2 - 45, 20, 20);
      screen.drawSprite("butterfridge", 50,  screen.height*(4/5)/2 - 45, 20, 20);
      screen.drawSprite("sink", 80,  screen.height*(4/5)/2 - 45, 20, 20);
      
      // Instructions for Crafting
      screen.drawText("Press E by the oven to craft items!", -60, screen.height*(4/5)/2 - 70, 10, "rgb(255,255,255)");
      
      screen.drawSprite("oven", 0,  screen.height*(4/5)/2 - 90, 40, 20);
      
      // Selling Instructions
      screen.drawText("Press E by the register to sell the item the customer wants!", -10, screen.height*(4/5)/2 - 110, 10, "rgb(255,255,255)");
      
      screen.drawSprite("register", 0,  screen.height*(4/5)/2 - 140, 10, 40);
    }
  }
}