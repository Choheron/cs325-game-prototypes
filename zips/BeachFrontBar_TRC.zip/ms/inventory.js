Inventory = class {
  // Params:
  // - int Size (Directly corresponds to amount of spaces in inventory) [NOT CURRENTLY SUPPORTED]
  // - bool stack (True if objects of the same name should stack, false if not) [NOT CURRENTLY SUPPORTED]
  // - autoOrganize (True if the inventory should auto organize the items by name)
  // ===== UI PARAMETERS
  // - BG Color (String rgb corresponding to the background color)
  // - Cell Color (String rgb corresponding to the color of the cells)
  // - Cell Border Color (String rgb corresponding to the border color of the cells)
  // - Item Quanitity Text Color (String rgb corresponding to the item text color in the inventory)
  // - Rounded? (Boolean corresponding to if the UI is to be rounded or not)
  constructor(size, stack, autoOrganize, bgColor, cellColor, cellBorderColor, itemTxtColor, rounded) {
    this.autoOrg = autoOrganize;
    
    this.bgCol = bgColor;
    this.cellCol = cellColor;
    this.cellBCol = cellBorderColor;
    this.textCol = itemTxtColor;
    this.rounded = rounded;
    this.hoverItem = null;
    
    this.count = 0;
    this.warehouse = [];
    
    this.full = false;
    // Delete Mode Check
    this.delete = false;
  }
  
  
  draw = function() {
    this.drawUI();
    
    // Check for mouse hovering to display currently hovered over item
    let xPos = (((screen.width - 30)*(4/5)/10) - (screen.width*(4/5)/2));
    let xInc = ((screen.width - 30)*(4/5)/10);
    let yPos = -(((screen.height - 30)*(4/5)/5) - (screen.height*(4/5)/2));
    let yInc = ((screen.height - 30)*(4/5)/5);
    for(let i = 1; i <= 50; i++) {
      if((mouse.x < (xPos + (xInc/2))) && (mouse.x > (xPos - (xInc/2))) &&
        (mouse.y < (yPos + (yInc/2))) && (mouse.y > (yPos - (yInc/2))) &&
        (this.get(i - 1) != "")) {
        let text = "";  
        if(this.delete) { text += "Throw away "; }
        text += this.get(i - 1);
        if(this.delete) { text += "?"; }
        screen.drawText(text, 0,  screen.height*(4/5)/2 - 8, 10, "rgb(255,255,255)");
      }
      // Increment cell drawing
      xPos += xInc;
      if(i % 10 == 0) {
        yPos -= yInc;
        xPos = (((screen.width - 30)*(4/5)/10) - (screen.width*(4/5)/2));
      }
    }
  }
  
  drawUI = function() {
    if(this.rounded) {
      screen.fillRoundRect(0, 0, screen.width*(4/5), screen.height*(4/5), 10, this.bgCol);
      let xPos = (((screen.width - 30)*(4/5)/10) - (screen.width*(4/5)/2));
      let xInc = ((screen.width - 30)*(4/5)/10);
      let yPos = -(((screen.height - 30)*(4/5)/5) - (screen.height*(4/5)/2));
      let yInc = ((screen.height - 30)*(4/5)/5);
      for(let i = 1; i <= 50; i++) {
        // Draw inventory slots
        screen.fillRoundRect(xPos, yPos, screen.width*(4/5)/12, screen.width*(4/5)/12, 1, this.cellCol);
        screen.drawRoundRect(xPos, yPos, screen.width*(4/5)/12, screen.width*(4/5)/12, 1, this.cellBCol);
        // Draw item if there is one in this slot
        if(this.warehouse[i - 1]) {
          this.warehouse[i - 1]["obj"].draw(xPos, yPos, screen.width*(4/5)/12 - 2, screen.width*(4/5)/12 - 2);
          if(this.warehouse[i - 1]["quantity"] > 1) {
            let textX = xPos + ((screen.width*(4/5)/12)/2) - 4;
            let textY = yPos + ((screen.width*(4/5)/12)/2) - 3;
            screen.drawText("x" + this.warehouse[i - 1]["quantity"], textX, textY, 5, this.textCol);
          }
        }
        // Increment cell drawing
        xPos += xInc;
        if(i % 10 == 0) {
          yPos -= yInc;
          xPos = (((screen.width - 30)*(4/5)/10) - (screen.width*(4/5)/2));
        }
      }
    } else {
      screen.fillRect(0, 0, screen.width*(4/5), screen.height*(4/5), this.bgCol);
      let xPos = (((screen.width - 30)*(4/5)/10) - (screen.width*(4/5)/2));
      let xInc = ((screen.width - 30)*(4/5)/10);
      let yPos = -(((screen.height - 30)*(4/5)/5) - (screen.height*(4/5)/2));
      let yInc = ((screen.height - 30)*(4/5)/5);
      for(let i = 1; i <= 50; i++) {
        // Draw Inventory Slots
        screen.fillRect(xPos, yPos, screen.width*(4/5)/12, screen.width*(4/5)/12, this.cellCol);
        screen.drawRect(xPos, yPos, screen.width*(4/5)/12, screen.width*(4/5)/12, this.cellBCol);
        //Draw item if there is one in this slot
        if(this.warehouse[i - 1]) {
          this.warehouse[i - 1]["obj"].draw(xPos, yPos, screen.width*(4/5)/12 - 2, screen.width*(4/5)/12) - 2;
          if(this.warehouse[i - 1]["quantity"] > 1) {
            let textX = xPos + ((screen.width*(4/5)/12)/2) - 4;
            let textY = yPos + ((screen.width*(4/5)/12)/2) - 3;
            screen.drawText("x" + this.warehouse[i - 1]["quantity"], textX, textY, 5, this.textCol);
          }
        }
        // Increment cell drawing
        xPos += xInc;
        if(i % 10 == 0) {
          yPos -= yInc;
          xPos = (((screen.width - 30)*(4/5)/10) - (screen.width*(4/5)/2));
        }
      }
    }
  }
  
  
  update = function() {
    if(keyboard.release.S) {
      this.sort();
    }
    
    // Delete mode code 
    if(this.delete) {
      // Check for mouse hovering to display currently hovered over item
      let xPos = (((screen.width - 30)*(4/5)/10) - (screen.width*(4/5)/2));
      let xInc = ((screen.width - 30)*(4/5)/10);
      let yPos = -(((screen.height - 30)*(4/5)/5) - (screen.height*(4/5)/2));
      let yInc = ((screen.height - 30)*(4/5)/5);
      for(let i = 1; i <= 50; i++) {
        if((mouse.x < (xPos + (xInc/2))) && (mouse.x > (xPos - (xInc/2))) &&
          (mouse.y < (yPos + (yInc/2))) && (mouse.y > (yPos - (yInc/2)))) {
          if(touch.press) {
            print("Removing: " + this.getIndex(i - 1) + "\n\tCurr (Pre-Remove) Quantity: " + this.warehouse[i - 1]["quantity"]);
            this.removeItem(this.getIndex(i - 1));
          }
        }
        // Increment cell drawing
        xPos += xInc;
        if(i % 10 == 0) {
          yPos -= yInc;
          xPos = (((screen.width - 30)*(4/5)/10) - (screen.width*(4/5)/2));
        }
      }
      
      if(keyboard.press.I || keyboard.press.ESCAPE) {
        this.delete = false;
      }
    }
  }
  
  
  // Returns the index of passed in item in inventory, returns -1 if not found.
  // (Item must be of custom type ITEM [INCLUDED IN THIS PACKAGE])
  findItem = function(item) {
    for(let i = 0; i < this.count; i++) {
      if(this.warehouse[i]["obj"] == item) {
        return i;
      }
    }
    return -1;
  }
  
  
  // Returns the index of passed in item in inventory, returns -1 if not found.
  // OVERRIDE FOR STRING NAME INPUT
  findString = function(name) {
    for(let i = 0; i < this.count; i++) {
      if(this.warehouse[i]["obj"].getName().toUpperCase() == name.toUpperCase()) {
        return i;
      }
    }
    return -1;
  }
  
  
  // Internal get method that just returns name based off of index
  get = function(index) {
    if(this.warehouse[index]) {
      return this.warehouse[index]["obj"]["name"];
    }
    return "";
  }
  
  
  // Return item stored at passed in index [RETURNS TYPE ITEM]
  getIndex = function(index) {
    if(this.warehouse[index]) {
      return this.warehouse[index]["obj"];
    }
    return null;
  }
  
  
  // Adds an item to the inventory (Item must be of custom type ITEM [INCLUDED IN THIS PACKAGE])
  addItem = function(item) {
    let index = this.findItem(item);
    if(index == -1) {
      // Return false and print to console if inventory is full and item cannot be stacked.
      if(this.full) {
        console.log("Inventory ERROR!");
        console.log("ERROR:\t Item: " + item.toString() + " cannot be added!");
        console.log("REASON:\t Item cannot stack and inventory is FULL");
        return false;
      }
      this.warehouse.push({obj: item, quantity: 1});
      this.count++;
      if(this.count == 30) {
        this.full = true;
      }
      if(this.autoOrg) {
          this.sort();
      }
    } else {
      this.warehouse[index]["quantity"]++;
    }
  }
  
  
  // Remove item from inventory and return it 
  // (Item must be of custom type ITEM [INCLUDED IN THIS PACKAGE])
  removeItem = function(item) {
    let index = this.findItem(item);
    if(index == -1) {
      console.log("Inventory WARNING!");
      console.log("WARN:\t Item: " + item.getName() + " cannot be removed!");
      console.log("REASON:\t Item not found in inventory!");
      return false;
    } else {
      this.warehouse[index]["quantity"]--;
      let out = this.warehouse[index];
      if(this.warehouse[index]["quantity"] <= 0) {
        this.warehouse.splice(index, 1);
        this.count--;
        this.sort();
      }
      return out;
    }
  }
  
  
  // Remove item from inventory and return it
  // (OVERLOADED FOR STRING NAME INPUT)
  removeItemString = function(name) {
    let index = this.findString(name);
    if(index == -1) {
      console.log("Inventory WARNING!");
      console.log("WARN:\t Item: " + name + " cannot be removed!");
      console.log("REASON:\t Item not found in inventory!");
      return false;
    } else {
      this.warehouse[index]["quantity"]--;
      let out = this.warehouse[index];
      if(this.warehouse[index]["quantity"] <= 0) {
        this.warehouse.splice(index, 1);
        this.count--;
        this.sort();
      }
      return out;
    }
  }
  
  
  sort = function() {
      this.warehouse.sort(function(a, b) {
          var textA = a["obj"].getName().toUpperCase();
          var textB = b["obj"].getName().toUpperCase();
          return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
      });
  }


  // toString function (If passed in value of debug is true, return information in a FORMATTED debug string.)
  toString = function(debug) {
      // Return simple debug if no arguments are passed in or if debug is false
      if(arguments.length == 0) {
          debug = false;
      }
      if(debug) {
          let out = "";
          out += "INVENTORY INFROMATION:\n";
          out += "Capacity: " + 30 + " [SIZE CUSTOMIZATION CURRENTLY LOCKED AT 30]\n";
          out += "Current Load: " + this.count + "\n";
          out += "Stackable: " + true + " [STACK ENABLE/DISABLE IS NOT CURRENTLY SUPPORTED]\n";
          out += "Auto Organize: " + this.autoOrg + "\n";
          out += "===== UI PARAMS:\n";
          out += "Background Color: " + this.bgCol + "\n";
          out += "Cell Color: " + this.cellCol + "\n";
          out += "Cell Border Color: " + this.cellBCol + "\n";
          out += "Rounded: " + this.rounded + "\n";
          out += "INVENTORY CONTENTS:\n";
          for(let c = 0; c < this.count; c++) {
              out += "\t" + (c + 1) + ". " + this.warehouse[c]["obj"].getName() + " (x" + this.warehouse[c]["quantity"] + ")\n";
          }
          return out;
      }
      return "Inventory Contents: " + this.warehouse;
  }
}





















