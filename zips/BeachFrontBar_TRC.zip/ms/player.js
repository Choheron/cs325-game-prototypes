Player = class {
  constructor(startX, startY, sprite, width, height, colliderClass) {
    this.X = startX;
    this.Y = startY;
    
    this.collide = colliderClass;
    
    this.sprite = sprite;
    this.width = width;
    this.height = height;
    
    this.speed = 0.5;
    
    this.wallet = 100;
    
    // Variables for displaying a pickup message
    this.pickupTimer = 100;
    this.pickup = this.pickupTimer;
    // Currently picked up item
    this.currPickup = null;
  }
  
  setSpeed = function(speed) {
    this.speed = speed;
  }
  
  draw = function() {
    screen.drawSprite(this.sprite, this.X, this.Y, this.width, this.height);
    
    // Display a pickup message
    if(this.pickup != this.pickupTimer) {
      screen.fillRoundRect(this.X + this.width/2 + 2.5, this.Y + this.height/2,
                           12, 6, 2, ("rgba(0,0,0," + (1-(this.pickup/this.pickupTimer)) + ")"));
      screen.drawText("+", this.X + this.width/2, this.Y + this.height/2, 5, "rgb(255, 255, 255)");
      screen.drawSprite(this.currPickup.getSprite(), this.X + this.width/2 + 5, this.Y + this.height/2, 5, 5);
    }
  }
  
  update = function() {
    // Update player speed in line with system refresh rate (fps)
    if(parseInt(system.fps) <= 70) {
      this.speed = 1;
    } else {
      this.speed = 0.5;  
    }
    
    // Movement Calculations
    if(keyboard.UP) {
      this.Y += this.speed;
      if(this.collide.checkCollide(this)) {
        this.Y -= this.speed;
      }
    }
    if(keyboard.DOWN) {
      this.Y -= this.speed;
      if(this.collide.checkCollide(this)) {
        this.Y += this.speed;
      }
    }
    if(keyboard.LEFT) {
      this.X -= this.speed;
      if(this.collide.checkCollide(this)) {
        this.X += this.speed;
      }
    }
    if(keyboard.RIGHT) {
      this.X += this.speed;
      if(this.collide.checkCollide(this)) {
        this.X -= this.speed;
      }
    }
    
    if(this.pickup < this.pickupTimer) {
      this.pickup++;
      if(this.pickup == this.pickupTimer) {
        this.currItem = null;
      }
    }
  }
  
  setPickup = function(item) {
    this.currPickup = item;
    this.pickup = 0;
  }
  
  // Add passed in int value to the players wallet
  earn = function(amt) {
    this.wallet += amt;
  }
  
  // Subtract passed in int value from the players current wallet balance
  deduct = function(amt) {
    this.wallet += amt;
  }
  
  // Return players current wallet balance
  checkBal = function() {
    return this.wallet;
  }
}





















