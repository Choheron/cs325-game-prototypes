Crafting = class {
  constructor(primitives, craftables, inventory) {
    this.base = primitives;
    this.recipes = craftables;
    
    this.iRef = inventory;
  }
  
  setLists = function(primitives, craftables) {
    this.base = primitives;
    this.recipes = craftables;
  }
  
  draw = function() {
    // Draw base menu
    screen.fillRoundRect(0, 0, screen.width*(3/4), screen.height*(4.5/5), 10, "rgb(196, 142, 55)");
    screen.drawText("Crafting Menu - Click on Desired Item to Craft", 0, screen.height*(4.5/5)/2 - 10, 8, "rgb(0,0,0)");
    
    let currY = screen.height*(3/4)/2 - 15;
    let yInt = (screen.height*(3/4))/this.recipes.length;
    for(let i = 0; i < this.recipes.length; i++) {
      if((mouse.y > currY - (yInt/2)) && (mouse.y < currY + (yInt/2))) {
        screen.fillRoundRect(0, currY, screen.width*(2.8/4), yInt, 5, "rgba(50,50,50, 0.2)");
      }
      
      screen.drawSprite(this.recipes[i].getSprite(), -(screen.width*(3/4)/2 - 40), currY, 20, 20);
      screen.drawRoundRect(-(screen.width*(3/4)/2 - 40), currY, 20, 20, 5, "rgb(100,100,100)");
      screen.drawText(this.recipes[i].getName(), -(screen.width*(3/4)/2 - 80), currY, 5, "rgb(0,0,0)");
      screen.drawText("-->", -(screen.width*(3/4)/2 - 120), currY, 5, "rgb(0,0,0)");
      
      let currX = screen.width*(3/4)/2 - 40;
      let xInt = 30;
      for(let j = 0; j < this.recipes[i].getRecipe().length; j++) {
        // Store local recipe
        let recipe = this.recipes[i].getRecipe();
        
        screen.drawSprite(this.getBase(recipe[j]).getSprite(), currX, currY, 15, 15);
        
        if(this.checkString(recipe[j])) {
          screen.drawRoundRect(currX, currY, 16, 16, 2, "rgb(0, 255, 0)");
        } else {
          screen.drawRoundRect(currX, currY, 16, 16, 2, "rgb(255, 0, 0)");
        }
        
        screen.drawText(this.getBase(recipe[j]).getName(), currX, currY - 10, 5, "rgb(0,0,0)");
        
        currX -= xInt;
      }
      currY -= yInt;
    }
  }
  
  update = function() {
    // Check for mouse click on a craftable object 
    let currY = screen.height*(3/4)/2 - 15;
    let yInt = (screen.height*(3/4))/this.recipes.length;
    
    for(let i = 0; i < this.recipes.length; i++) {
      if((mouse.y > currY - (yInt/2)) && (mouse.y < currY + (yInt/2))) {
        if(mouse.release) {
          print("Mouse Clicked! Checking Craftable for " + this.recipes[i].getName());
          if(this.checkCraftable(this.recipes[i])) {
            print("CRAFTABLE! Attempting to craft");
            this.craft(this.recipes[i]);
            return;
          }
        }
      }
      
      currY -= yInt;
    }
  }
  
  // Check the player inventory for the passed in item.
  check = function(item) {
    if(this.iRef.findItem(item) != -1) {
      return true;
    }
    return false;
  }
  
  // Check the player inventory for an item sharing this name
  checkString = function(name) {
    if(this.iRef.findString(name) != -1) {
      return true;
    }
    return false;
  }
  
  getBase = function(name) {
    for(let index = 0; index < this.base.length; index++) {
      if(name.toUpperCase() == this.base[index].getName().toUpperCase()) {
        return this.base[index];
      }
    }
    return "";
  }
  
  checkCraftable = function(item) {
    for(let j = 0; j < item.getRecipe().length; j++) {
      // Store local recipe
      let recipe = item.getRecipe();
      
      if(!this.checkString(recipe[j])) {
        return false;
      } 
    }
    return true;
  }
  
  craft = function(item) {
    // Store local recipe
    let recipe = item.getRecipe();
    
    for(let j = 0; j < item.getRecipe().length; j++) {
      this.iRef.removeItemString(recipe[j]);
    }
    
    this.iRef.addItem(item);
  }
}








































