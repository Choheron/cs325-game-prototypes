Player = class {
  constructor(gold) {
    this.funds = gold;
  }
  
  getGold = function() {
    return this.funds;
  }
  
  earn = function(amount) {
    this.funds += amount;
  }
  
  charge = function(amount) {
    this.funds -= amount;
  }
}