MapDriver = class {
  constructor(width, height, cellSize, map, player) {
    this.width = width;
    this.height = height;
    this.cellSize = cellSize;
    this.ref = map;
    
    this.map = [];
    this.buildMap();
    
    this.player = player;
    this.building = false;
    this.currSelect = null;
    
    this.income = 0;
  }
  
  getIncome = function() {
    return this.income;
  }
  
  // Set the current draw to sprite and activate building mode
  setBuild = function(spriteName) {
    if(spriteName == null) {
      this.building = false;
      this.currSelect = null;
    } else {
      this.building = true;
      this.currSelect = spriteName;
    }
  }
  
  buildMap = function() {
    // Fill map with inital empty values 
    for(let i = 0; i < this.height; i++) {
      let temp = [];
      for(let j = 0; j < this.width; j++) {
        // Initalize map to empty values
        // NOTE map.get USES ORIGIN AT BOTTOM LEFT NOT TOP LEFT
        temp.push(null);
      }
      this.map.push(temp);
    }
  }
  
  set = function(x, y, val) {
    this.map[y][x] = val;
  }
  
  peek = function(x, y) {
    return this.map[y][x];
  }
  
  // Get mouse position in terms of the map
  getMousePos = function() {
    let xCell = Math.floor((mouse.x + screen.width/2) / (screen.width/32));
    let yCell = Math.floor((mouse.y + screen.height/2) / (screen.height/18));
    
    if(xCell < 0) {
      xCell = 0;
    } else if(xCell >= 32) {
      xCell = 31;
    }
    
    if(yCell < 0) {
      yCell = 0;
    } else if(yCell >= 18) {
      yCell = 17;
    }
    
    return {X: xCell, Y: yCell};
  }
  
  
  // Return the grid X and Y coordinate of a corrdinate set
  worldCoordsToGrid = function(x, y) {
    let xCell = Math.floor((x + screen.width/2) / (screen.width/32));
    let yCell = Math.floor((y + screen.height/2) / (screen.height/18));
    
    return {X: xCell, Y: yCell};
  }
  
  
  // Return the grid X and Y coordinate of the object
  worldToGrid = function(object) {
    let xCell = Math.floor((object.X + screen.width/2) / (screen.width/32));
    let yCell = Math.floor((object.Y + screen.height/2) / (screen.height/18));
    
    return {X: xCell, Y: yCell};
  }
  
  
  // Return the X and Y of a grid object
  gridToWorld = function(x, y) {
    let xCoord = -(screen.width/2) + (x * this.cellSize) + this.cellSize/2;
    let yCoord = -(screen.height/2) + (y * this.cellSize)  + this.cellSize/2;
    
    return {X: xCoord, Y: yCoord};
  }
  
  
  // Update map and all contained objects
  update = function() {
    // Run update for all map items
    for(let i = 0; i < 18; i++) {
      for(let j = 0; j < 32; j++) {
        if(this.map[i][j] != null) {
          let action = this.map[i][j].update();
          if(action != null) {
            switch(action['type']) {
              case 'PAY':
                // print('Action PAY Run with Payout of: ' + action['amount']);
                player.earn(action['amount']);
                break;
              case 'AUTOPAY':
                // print('Action AUTOPAY Run with Payout of: ' + action['amount']);
                player.earn(action['amount']);
                break;
            }
          }
        }
      }
    }
    
    // Fucntionality to buy a new Mine
    if(touch.press && this.building) {
      // Mine constructor(xPos, yPos, width, height, payout, cost, resource, workers, maxWorkers, levelEarn)
      let mPos = this.getMousePos();
      let objCoords = this.gridToWorld(mPos['X'], mPos['Y']);
      let newMine = new Mine(objCoords['X'], objCoords['Y'], screen.width/32, screen.height/18, 5, 200, "Spice", 0, 4, 2)
      if((this.player.getGold() >= newMine.cost) && (this.peek(mPos['X'], mPos['Y']) == null)) {
        // Place a mine and reduce the wallet if conditions are met
        this.set(mPos['X'], mPos['Y'], newMine); 
        this.player.charge(newMine.cost);
        // Turn off building
        this.setBuild(null);
      }
    }
    
    // Fucntionality to buy a new Worker
    if(touch.press && keyboard.SHIFT) {
      // Mine constructor(xPos, yPos, width, height, payout, cost, resource, workers, maxWorkers, levelEarn)
      let mPos = this.getMousePos();
      let objCoords = this.gridToWorld(mPos['X'], mPos['Y']);
      if((this.player.getGold() >= 250) && (this.peek(mPos['X'], mPos['Y']) != null)) {
        if(this.peek(mPos['X'], mPos['Y']).addWorker()) {
          // Update the mine to add new worker
          this.player.charge(250);
        }
      }
    }
    
    // Fucntionality to buy a level up
    if(touch.press && keyboard.CONTROL) {
      // Mine constructor(xPos, yPos, width, height, payout, cost, resource, workers, maxWorkers, levelEarn)
      let mPos = this.getMousePos();
      let objCoords = this.gridToWorld(mPos['X'], mPos['Y']);
      let levelCost = this.peek(mPos['X'], mPos['Y']).levelCost;
      if((this.player.getGold() >= levelCost) && (this.peek(mPos['X'], mPos['Y']) != null)) {
        // Update the mine to add new worker
        this.player.charge(levelCost);
        this.peek(mPos['X'], mPos['Y']).levelUp();
      }
    }
    
    // Cancel building if the user presses ESC while placing objects
    if(keyboard.press.ESCAPE && this.building) {
      // Turn off building
      this.setBuild(null);
    }
  }
  
  
  // Draw a box around the cell the player has selected
  // Draw items in the map
  draw = function() {
    // Draw outline of item being placed
    if(this.building) {
      let mousePos = this.getMousePos();
      let worldCoords = this.gridToWorld(mousePos['X'], mousePos['Y']);
      screen.fillRoundRect(worldCoords['X'], worldCoords['Y'], this.cellSize, this.cellSize, 1, 'rgb(0, 255, 0)');
      screen.drawSprite(this.currSelect, worldCoords['X'], worldCoords['Y'], this.cellSize, this.cellSize);
    }
    
    // Income Counter
    let income = 0;
    // Run draw for all map items
    for(let i = 0; i < 18; i++) {
      for(let j = 0; j < 32; j++) {
        if(this.map[i][j] != null) {
          this.map[i][j].draw();  
          income += this.map[i][j].payout * this.map[i][j].workers;
        }
      }
    }
    this.income = income;
  }
  
  // If called, draw details of the object passed in
  drawDetails = function() {
    let mousePos = this.getMousePos();
    let worldCoords = this.gridToWorld(mousePos['X'], mousePos['Y']);
    let obj = null;
    
    // Draw details for object hovered over
    if(this.peek(mousePos['X'], mousePos['Y']) == null) {
      return;
    } else {
      obj = this.peek(mousePos['X'], mousePos['Y']);
    }
    
    // Get coordinate anchors
    let xLoc = worldCoords['X'] + (this.cellSize/2) + 20;
    let yLoc = worldCoords['Y'] + (this.cellSize/2) + 10;
    
    if(xLoc >= screen.width/2) {
      xLoc = (worldCoords['X'] - (this.cellSize/2) - 20);
    }
    if(yLoc >= screen.height/2) {
      yLoc = (worldCoords['Y'] - (this.cellSize/2) - 10);
    }
    
    // Draw Box
    screen.fillRoundRect(xLoc, yLoc, 40, 20, 2, "rgb(116,214,206)");
    screen.drawRoundRect(xLoc, yLoc, 40, 20, 2, "rgb(0,0,0)");
    
    // Draw item details
    screen.drawText(("Workers: " + obj.workers + "/" + obj.maxWorkers), xLoc, yLoc + 7, 5, "rbg(0,0,0)");
    screen.drawText(("Level: " + obj.level), xLoc, yLoc + 2.25, 5, "rbg(0,0,0)");
    screen.drawText(("Level Cost: " + obj.levelCost), xLoc, yLoc - 2.25, 5, "rbg(0,0,0)");
    screen.drawText(("Payout: " + obj.payout), xLoc, yLoc - 7, 5, "rbg(0,0,0)");
  }
  
  
  // FOR DEBUGGING
  drawDebug = function(object) {
    let currX = -(screen.width/2) + (this.cellSize/2);
    let currY = (screen.height/2) - (this.cellSize/2);
    let count = 0;
    
    for(let i = 0; i < 18; i++) {
      for(let j = 0; j < 32; j++) {
        let col = "rgb(255, 0, 0)";
        if(this.map[17 - i][j] != null) {
          screen.fillRect(currX, currY, this.cellSize, this.cellSize, "rgba(0, 255, 0, 0.5)");
        }
        screen.drawText(count, currX, currY, 5, col);
        count++;
        currX += this.cellSize;
      }
      currX = -(screen.width/2) + (this.cellSize/2);
      currY -= this.cellSize;
    }
  }
}