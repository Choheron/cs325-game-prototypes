Button = class {
  constructor(name, xPos, yPos, width, height, text, textSize, textColor, baseColor, selColor, bordColor, rounded) {
    this.name = name;
    this.xPos = xPos;
    this.yPos = yPos;
    this.width = width;
    this.height = height;
    
    this.text = text;
    this.textSize = textSize;
    this.textColor = textColor;
    
    this.baseColor = baseColor;
    this.selColor = selColor;
    this.bordColor = bordColor;
    this.rounded = rounded;
    
    this.selected = false;
  }
  
  // Print all infromation about the button
  DEBUGPRINTINFO = function() {
    print("================DEBUG INFO FOR BUTTON");
    print("NAME: " + this.name);
    print("X Position: " + this.xPos);
    print("Y Position: " + this.yPos);
    print("Width: " + this.width);
    print("Height: " + this.height);
    print("Text: " + this.text);
    print("Text Size: " + this.textSize);
    print("Text Color: " + this.textColor);
    print("Base Color: " + this.baseColor);
    print("Selected Color: " + this.selColor);
    print("Border Color: " + this.bordColor);
    print("Rounded: " + this.rounded);
    print("Selected: " + this.selected);
  }
  
  // UPDATE METHOD - To be called in master class update function.
  // NOTE: THIS FUNCTION CALLS AND ALREADY CHECKS FOR USER CLICKS -- DO NOT DO SO IN THE MASTER UPDATE FUNC
  update = function() {
    // this.DEBUGPRINTINFO();
    if(touch.press) {
      if(this.checkHit(touch.x, touch.y)) {
        this.toggle();
        if(this.selected) {
          return this.name;
        }
      }
    }
  }
  
  // DRAW METHOD - To be called in master class draw function.
  draw = function() {
    let buttonColor = (this.selected ? this.selColor : this.baseColor);
    if(this.rounded) {
      screen.fillRoundRect(this.xPos, this.yPos, this.width, this.height, 10, buttonColor);
      screen.drawRoundRect(this.xPos, this.yPos, this.width, this.height, 10, this.bordColor);
    } else {
      screen.fillRect(this.xPos, this.yPos, this.width, this.height, buttonColor);
      screen.drawRect(this.xPos, this.yPos, this.width, this.height, this.bordColor);
    }
    
    this.drawText();
  }
  
  // Helper function for drawing multi-lane text - DO NOT CALL EXTERNALLY
  drawText = function() {
    // Procedurally draw if Array
    if(Array.isArray(this.text)) {
      let yVal = ((this.text.length * 10)/2);
      for(let i = 0; i < this.text.length; i++) {
        screen.drawText(this.text[i], this.xPos, this.yPos + yVal, this.textSize, this.textColor);
        yVal -= 10;
      }
    // Draw normally if String
    } else {
      screen.drawText(this.text, this.xPos, this.yPos, this.textSize, this.textColor);
    }
  }
  
  // Set coordinates of button
  setXY = function(xPos, yPos) {
    this.xPos = xPos;
    this.yPos = yPos;
  }
  
  // Return X and Y position in a list
  getXY = function() {
    let out = [this.xPos, this.yPos];
    return out;
  }
  
  // Return the current value of selected (If the button is toggled on or not)
  isSelected = function() {
    return this.selected;
  }
  
  // Set the status of selected to the passed in value
  setSelected = function(selected) {
    this.selected = selected;
    return this.selected;
  }
  
  // Toggle select status of the button
  toggle = function() {
    this.selected = !this.selected;
    return this.selected;
  }
  
  // Set text to the passed in value
  setText = function(text) {
    this.text = text;
  }
  
  // Return the current text in either string or list form based off of user input
  getText = function(type) {
    if(Array.isArray(this.text)) {
      if(type) {
        let out = "";
        for(let i = 0; i < this.text.length; i++) {
          out += (this.text[i] + " ");
        }
        return out;
      }
    }
    return this.text;
  }
  
  // Set name as the passed in name
  setName = function(name) {
    this.name = name;
  }
  
  // Return the current name of the button
  getName = function() {
    return this.name;
  }
  
  // Check if the passed in coordinates fall into the hitbox of the button.
  checkHit = function(hitX, hitY) {
    if((hitX > (this.xPos-(this.width/2))) && (hitX < (this.xPos+(this.width/2)))) {
      if((hitY > (this.yPos-(this.height/2))) && (hitY < (this.yPos+(this.height/2)))) {
        return true;
      }
    }
    return false;
  }
  
}