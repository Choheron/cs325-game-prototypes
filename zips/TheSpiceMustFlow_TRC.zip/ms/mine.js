Mine = class {
    constructor(xPos, yPos, width, height, payout, cost, resource, workers, maxWorkers, levelEarn) {
      this.X = xPos;
      this.Y = yPos;
      this.width = width;
      this.height = height;

      // Cost and Payout Variables
      this.payout = payout;
      this.cost = cost;
      this.resource = resource;
      this.mult = levelEarn;
      this.levelCost = cost *= levelEarn;

      // Auto workers variables
      this.workers = workers;
      this.maxWorkers = maxWorkers;

      // Level Affects the payout of the mine
      this.level = 1;

      // Counter for auto mining
      this.step = 0;
      this.maxStep = parseInt(system.fps);
    }

    levelUp = function() {
        this.level++;
        this.payout *= this.mult;
        this.levelCost *= 2;
    }

    addWorker = function() {
        if(this.workers == this.maxWorkers) {
            return false;
        } 
        this.workers++;
        return true;
    }

    // Return the current pay for the 
    pay = function(auto) {
        // Run if block if the payout is from an automatic call
        if(auto) {
            return {type:"AUTOPAY", amount:(this.payout * this.workers)};
        }
        // Run if the pay function is called by the user clicking
        return {type:"PAY", amount:(this.payout)};
    }

    update = function() {
        if((mouse.x < (this.X + (this.width/2))) && (mouse.x > (this.X - (this.width/2))) &&
          (mouse.y < (this.Y + (this.height/2))) && (mouse.y > (this.Y - (this.height/2))) &&
          (touch.press)){
            return this.pay(false);
        }

        // Step if there is workers on the mine
        if(this.workers > 0) {
            this.step++;
            if(this.step >= this.maxStep) {
                this.step = 0;
                return this.pay(true);
            }
        }
    }

    draw = function() {
      screen.drawSprite("mine", this.X, this.Y, this.width, this.height);
    }
    
    
    debug = function() {
      print("Mine Information:\n");
      print("\t X: " + this.X + "\n");
      print("\t Y: " + this.Y + "\n");
      print("\t Width: " + this.width + "\n");
      print("\t Height: " + this.height + "\n");
      print("\t Payout: " + this.payout + "\n");
      print("\t Cost: " + this.cost + "\n");
      print("\t Resource: " + this.resource + "\n");
      print("\t Workers: " + this.workers + "\n");
      print("\t MaxWorkers: " + this.maxWorkers + "\n");
      print("\t LevelEarn: " + this.mult + "\n");
      print("\t LEVEL: " + this.level + "\n");
    }
}
























