init = function() {
  // Initalize Reference to Base Map
  map = maps["map1"];
  
  // Player Reference
  player = new Player(200);
  
  // NOTE: MAPDRIVER HANDLES ALL OBJECT INTERACTIONS
  mapDriver = new MapDriver(32, 18, screen.width/32, map, player);
  
  // UI REFERENCE
  ui = new UI(player);
  ui.setDriverRef(mapDriver);
}

update = function() {
  mapDriver.update();
  
  
  
  ui.update();
}

draw = function() {
  screen.drawMap("map1", 0, 0, screen.width, screen.height);
  
  mapDriver.draw();
  
  ui.draw();
  
  mapDriver.drawDetails();
}