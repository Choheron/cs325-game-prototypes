UI = class {
  constructor(player) {
    this.playerRef = player;
    this.gold = player.getGold();
    
    this.driverRef = null;
    
    // Button Constructor
    // constructor(name, xPos, yPos, width, height, text, textSize, textColor, baseColor, selColor, bordColor, rounded)
    this.buildButtons = [
      new Button("newMine", -135, 94, 80, 10, "Buy Mine: 200", 10, "rgb(255,255,255)", "rgb(130,128,85)", "rgb(130,128,85)", "rgb(0,0,0)", true)
      ];
  }
  
  setDriverRef = function(driver) {
    this.driverRef = driver;
  }
  
  draw = function() {
    // Draw Gold Counter
    screen.fillRoundRect(-(screen.width/2) + 40, -(screen.height/2)+10, 110, 40, 5, "rgba(0,0,0,0.8)")
    // Draw Counter SubBackground
    screen.fillRoundRect(-(screen.width/2) + 60, -(screen.height/2)+15, 60, 20, 5, "rgb(73,73,73 )")
    // Draw Gold Sprite and Text
    screen.drawSprite("spicecoin", -(screen.width/2) + 15, -(screen.height/2)+15, 20, 20)
    screen.drawText(this.gold, -(screen.width/2) + 60, -(screen.height/2)+15, 15, "rgb(255,255,255)");
    
    // Worker cost text
    screen.drawText("Buy Worker: (250)", -(screen.width/2) + 35, -(screen.height/2)+41, 8, "rgb(255,255,255)");
    screen.drawText("Shift + Click", -(screen.width/2) + 60, -(screen.height/2)+35, 8, "rgb(255,255,255)");
    
    // Level cost text
    screen.drawText("Level Mine: (Var)", -(screen.width/2) + 35, -(screen.height/2)+54, 8, "rgb(255,255,255)");
    screen.drawText("Control + Click", -(screen.width/2) + 60, -(screen.height/2)+48, 8, "rgb(255,255,255)");
    
    // Draw Gold Counter
    screen.fillRoundRect((screen.width/2) - 40, -(screen.height/2)+10, 100, 40, 5, "rgba(0,0,0,0.8)")
    // Draw Counter SubBackground
    screen.fillRoundRect((screen.width/2) - 45, -(screen.height/2)+11, 80, 15, 5, "rgb(73,73,73 )")
    // Draw Income Label
    screen.drawText("Current Auto Payout:", (screen.width/2)-45, -(screen.height/2)+25, 7, "rgb(255,255,255)");
    // Draw Income Counter
    screen.drawText(this.income, (screen.width/2)-45, -(screen.height/2)+11, 10, "rgb(255,255,255)");
    
    // Draw buy menu to buy objects
    for(let i = 0; i < this.buildButtons.length; i++) {
      this.buildButtons[i].draw();
    }
  }
  
  update = function() {
    this.gold = player.getGold(); 
    this.income = this.driverRef.getIncome();
    
    // Update buttons
    for(let i = 0; i < this.buildButtons.length; i++) {
      let name = this.buildButtons[i].update();
      if(name) {
        this.buildButtons[i].toggle();
        switch(name) {
          case 'newMine':
            this.driverRef.setBuild('mine');
            break;
        }
      }
    }
  }
  
  
}