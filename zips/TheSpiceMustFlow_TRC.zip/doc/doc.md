# The Spice Must Flow - Assignment 3B

### **Originality:**	
This is both a final product of a game and a proof of concept regarding some ideas I had for the underlying system of a tycoon game. The mines will run on their own
once a worker is placed on them and the user can also harvest from the mines by clicking on them. This is original in that it is a kind of game that I have personally
never made before and the systems under it are difficult to implement.

### **Technical	Merit:**
Technical merit comes from its class based foundation in the underlying code. The player can place mines anywhere and work on them.

Below are some examples of technical feats:
* The majority of the UI will be based off of the size of the user's screen, to allow for the perfect viewing no matter what size screen is playing.
* The placement system is dynamic and allows for mines to be placed anywhere.
* The popup over the mines is dynamic and will move to stay on screen.
* The income meter changes with how much income will be earned with each auto payout.
* The UI is responsive.

### **Prototype	Postmortem:**
My time constraints have proven to be very difficult as of late and thusly I was not able to implement everything I wanted to implement.

### **Prototype	Assets:**	
The current version of the game has no sounds, so no credit is due there. All other assets and code are my (*Thomas Campbell*) own work and I take full credit.

### **Prototype	Closest	Other	Game:**
This game has been inspired by other tycoon games where the user can build and run a resturant while also trying to be fast and maintain income. This is close
to games like "*Cookie CLicker*" and "*Resturant Tycoon*".

### **High	Concept:**
You are the owner of a mining operation and need to make as much profit as you can so you can expand and grow as a company!

### **Theme:**
Themes:
None Implemented

### **Mandated	Variety:**
**Input Type:** Direct, the user places and operats stations with the mouse.

**Randomness:** Based off of the player's build, every experience will be random.

**Genre**: Management / Tycoon / Capitalism

**Play Style**: Calming OR Fast Paced play, there really is no true loss condition at this point so the user can always try to relax.

### **Prototype	Goal:**	What	game	mechanic	is	this	prototype	evaluating?
This prototype is evaluating an entirely new type of game from my previous one. This game is built off of some of the frameworks from Beachfront bar and is testing
collision and dynamic map making.

### Future Plans
**If I had more time** I would work to better the systems in this and add a use for the gold besides upgrading the mines and income. This could be adding new buildings
or changing how the game interacts when the user reaches certian levels of wealth like addig taxes, etc.