#	Digital Assignment 4A - Eye Spy
*	**Originality:**	The game is based around a procedural sight system that allows the player to have mystery and an area of viewing in the game. This sight system adds
to the fear of the enemies randomy moving.
*	**Technical	Merit:**	As usual, my games focus a lot more on the systems programming side of things as I really enjoy creating complicated and interesting
systems for the game.
*	**Prototype	Postmortem:**	I learned a lot about calculating distances and clamping the values required. I also learned a lot about making sure my systems arent too
complicated as I allowed this one to become too complicated and jumbled up in terms of code. 
*	**Prototype	Assets:**	ALL assets made from scratch.
*	**Prototype	Closest	Other	Game:**	Similar to games where fog of war is in play. (NO CODE USED FROM OTHER GAMES)
*	**High Concept:**	Survive for as many moves as you can while being hunted down by big eyes!
*	**Theme:** None (Not required)
*	**Prototype	Goal:**	Testing the hidden system in the grid based off of proximity and vision.
*	**Player	Experience	Goals:**	I want my players to enjoy the gameplay and make their own fun when this prototype has been expanded into an entire game.
*	**Gameplay:**	Move and survive as long as you can in order to get the highest score.
*	**Strategies:**	Slow paced and deliberate gameplay.
*	**Target	Audience:**	Anyone interested in stealth/movement based games.
*	**Play Time:**	Depends on your survivability.