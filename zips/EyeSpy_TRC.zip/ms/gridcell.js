GridCell = class {
  // Constructor
  constructor(name, collisionType, xPos, yPos, gridX, gridY, size, floorSprite, gridRef) {
    this.name = name;
    this.collide = collisionType;
    
    // Store a reference to parent grid
    this.grid = gridRef;
    this.gX = gridX;
    this.gY = gridY;
    
    this.X = xPos;
    this.Y = yPos;
    this.size = size;
    
    this.floorSprite = floorSprite;
    this.item = null;
    
    // Controls the draw function
    this.visible = 1;
    
    // Boolean to see if this cell is in enemy sight
    this.enemySight = false;
  }
  
  // Set the object reference of the item (for it being occupied by something)
  setItem = function(itemIn) {
    this.item = itemIn;
  }
  
  getItem = function() {
    return this.item;
  }
  
  setVisible = function(visible){
    this.visible = visible;
  }
  
  // X Position Getter
  getX = function() {
    return this.X;
  }
  
  // Set the new X location of the cell
  setX = function(newX, newWorldX) {
    this.X = newX;
  }
  
  // Y Position Getter
  getY = function() {
    return this.Y;
  }
  
  // Set the new Y location of the cell
  setY = function(newY, newWorldY) {
    this.Y = newY;
  }
  
  // Get neighboring cell
  getNeighbor = function(dx, dy) {
    return this.grid[this.gX + dx][this.gY + dy];
  }
  
  // Get all neighboring cells
  getAdjacentNeighbors = function() {
    return this.shuffle([
      this.getNeighbor(0, -1),
      this.getNeighbor(0, 1),
      this.getNeighbor(-1, 0),
      this.getNeighbor(1, 0)
    ]);
  }
  
  // Get walkable neighboring cells
  getAdjacentWalkNeighbors = function() {
    return this.getAdjacentNeighbors().filter(t => (t.collide == 0));
  }
  
  // Get all connected tiles to this one
  getConnectedTiles = function(){
    let connectedTiles = [this];
    let frontier = [this];
    while(frontier.length){
        let neighbors = frontier.pop().getAdjacentWalkNeighbors().filter(t => !connectedTiles.includes(t));
        connectedTiles = connectedTiles.concat(neighbors);
        frontier = frontier.concat(neighbors);
      }
    return connectedTiles;
  }
  
  shuffle = function(arr){
    let temp, r;
    for (let i = 1; i < arr.length; i++) {
        r = Math.floor(Math.random()*(i+1));
        temp = arr[i];
        arr[i] = arr[r];
        arr[r] = temp;
    }
    return arr;
  }
  
  draw = function() {
    if(this.visible < 1) {
      // Draw Floor Sprite
      screen.drawSprite(this.floorSprite, this.X, this.Y, this.size, this.size);
      // Draw item if there is one and the cell is visible
      if(this.item) {
        this.item.draw();
      }
      // Tint red if this cell is in enemy sight
      if(this.enemySight) {
        screen.fillRect(this.X, this.Y, this.size, this.size, 'rgba(255,0,0,0.2)');
      }
    }
    
    // Place fog of war based off of distance values
    if(this.visible != 0) {
      screen.fillRect(this.X, this.Y, this.size, this.size, "rgba(0,0,0," + this.visible + ")");
      // screen.drawText(this.visible.toFixed(2), this.X, this.Y, 5, "rgb(255,0,0)"); // DEBUG VISIBILITY DRAW
      return;
    }
  }
  
  update = function() {
  }
}