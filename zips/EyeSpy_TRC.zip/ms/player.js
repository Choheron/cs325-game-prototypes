Player = class {
  // Constructor
  constructor(sprite, size, health, sight, gridX, gridY, gridRef) {
    this.sprite = sprite;
    this.size = size;
    this.health = health;
    this.sight = sight;
    
    this.gX = gridX;
    this.gY = gridY;
    
    this.gridRef = gridRef;
    this.type = 'PLAYER';
    
    this.moveCount = 0;
  }
  
  checkVisible = function(coords) {
    let checkX = coords['X'];
    let checkY = coords['Y'];
    
    let distX = Math.abs(this.gX - checkX);
    let distY = Math.abs(this.gY - checkY);
    
    let distance = distX**2 + distY**2;
    
    // Clamp Lower Values
    if((1 - (this.sight/distance)) < 0.1) {
      return 0;
    // Clamp Higher Values
    } else if((1 - (this.sight/distance)) >= 0.8) {
      return 1;
    } else {
    // Return Middle Values
      return (1 - (this.sight/distance));
    }
  }
  
  draw = function() {
    let currX = this.gridRef.GRID[this.gX][this.gY].getX();
    let currY = this.gridRef.GRID[this.gX][this.gY].getY();
    screen.drawSprite(this.sprite, currX, currY, this.size, this.size);
  }
  
  update = function() {
    // DEBUG: print("PlayerLoc: " + this.gX + "," + this.gY);
    
    // Handle player movement
    if(keyboard.press.UP) {
      // If possible, move player UP
      if(!this.gridRef.checkCollide(this.gX + 1, this.gY)) {
        this.gX += 1;
        this.gridRef.move(1);
        this.moveCount++;
        this.gridRef.update();
      }
    }
    if(keyboard.press.DOWN) {
      // If possible, move player DOWN
      if(!this.gridRef.checkCollide(this.gX - 1, this.gY)) {
        this.gX -= 1;
        this.gridRef.move(2);
        this.moveCount++;
        this.gridRef.update();
      }
    }
    if(keyboard.press.LEFT) {
      // If possible, move player LEFT
      if(!this.gridRef.checkCollide(this.gX, this.gY - 1)) {
        this.gY -= 1;
        this.gridRef.move(3);
        this.moveCount++;
        this.gridRef.update();
      }
    }
    if(keyboard.press.RIGHT) {
      // If possible, move player RIGHT
      if(!this.gridRef.checkCollide(this.gX, this.gY + 1)) {
        this.gY += 1;
        this.gridRef.move(4);
        this.moveCount++;
        this.gridRef.update();
      }
    }
  }
}