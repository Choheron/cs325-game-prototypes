Enemy = class {
  // Constructor
  constructor(sprite, size, health, sight, gridX, gridY, gridRef) {
    this.sprite = sprite;
    this.size = size;
    this.health = health;
    this.sight = sight;
    
    this.gX = gridX;
    this.gY = gridY;
    
    this.gridRef = gridRef;
    this.type = 'ENEMY';
  }
  
  move = function() {
    let dir = Math.floor(Math.random()*(4) + 1);
    let nC = null;
    switch(dir) {
      // Grid.moveItem(oldX, newX, oldY, newY)
      case 1:
        // Check if can move and move entity
        if(this.gridRef.moveItem(this.gX, this.gX, this.gY, this.gY + 1)){
          // Set position (for if they could move or not)
          this.gY = this.gY + 1; 
        }
        break;
      case 2:
        if(this.gridRef.moveItem(this.gX, this.gX, this.gY, this.gY - 1)) {
          this.gY = this.gY - 1; 
        }
        break;
      case 3:
        if(this.gridRef.moveItem(this.gX, this.gX - 1, this.gY, this.gY)) {
          this.gX = this.gX - 1; 
        }
        break;
      case 4:
        if(this.gridRef.moveItem(this.gX, this.gX + 1, this.gY, this.gY)) {
          this.gX = this.gX + 1; 
        }
        break;
    }
    
    // print("EnemyLoc: " + this.gX + "," + this.gY + " Collide: " + this.gridRef.GRID[this.gX][this.gY].collide); // DEBUG
  }
  
  draw = function() {
    let currX = this.gridRef.GRID[this.gX][this.gY].getX();
    let currY = this.gridRef.GRID[this.gX][this.gY].getY();
    screen.drawSprite(this.sprite, currX, currY, this.size, this.size);
  }
  
  update = function() {
    return;
  }
}