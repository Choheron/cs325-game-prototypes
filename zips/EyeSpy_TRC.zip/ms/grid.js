Grid = class {
  constructor(centerX, centerY, cellSize, width, height, enemyList) {
    this.genRate = 0.25;
    this.X = centerX;
    this.Y = centerY;
    
    this.cellsize = cellSize;
    this.width = width;
    this.height = height;
    
    this.GRID = [];
    
    // THESE NEEDS TO BE ASSIGNED BEFORE USE
    this.playerRef = null;
    this.pX = null;
    this.pY = null;
    
    // THIS NEEDS TO BE ASSIGNED BEFORE USE
    this.enemies = null;
    
    let status = this.buildGrid();
    let genCount = 1;
    while(!status) {
      print("\tRetrying Map Generation... Attempt " + genCount);
      genCount++;
      status = this.buildGrid();
    }
  }
  
  buildGrid = function() {
    print("Attempting to build map...");
    // Clear the grid just in case
    this.GRID = [];
    let walkTiles = 0;
    
    // Populate the grid
    let currY = this.Y - (((this.height-1)/2) * this.cellsize);
    for(let row = 0; row < this.height; row++) {
      let temp = [];
      let currX = this.X - ((this.width/2) * this.cellsize);
      // Generate Walls and Such
      // GridCell Constructor: constructor(name, collisionType, xPos, yPos, gridX, gridY, size, floorSprite, gridRef)
      for(let col = 0; col < this.width; col++) {
        // Generate Wall and Floor Randomly
        if(Math.random() < this.genRate || !this.inBounds(row, col)) {
          temp.push(new GridCell(row + " " + col, 1, currX, currY, row, col, this.cellsize, "wall", this.GRID));
        } else {
          temp.push(new GridCell(row + " " + col, 0, currX, currY, row, col, this.cellsize, "floor", this.GRID));
          walkTiles++;
        }
        
        
        currX += this.cellsize;
      }
      currY += this.cellsize;
      currX = this.X - ((this.width/2) * this.cellsize);
      this.GRID.push(temp);
    }
    
    let randCoords = this.getWalkCoords();
    let walkableCells = this.getCell(randCoords['X'], randCoords['Y']).getConnectedTiles().length;
    if(walkTiles != walkableCells) {
      print("\tMAP HAS ISLANDS [GENERATION FAILED]... Ratio(Ex/Ac): " + walkTiles + "/" + walkableCells);
      return false;
    }
    print("Map Sucessfully Built!");
    return true;
  }
  
  // Check and see if the player is dead
  checkDeath = function() {
    let row = this.pX;
    let col = this.pY;
    for(let i = -1; i < 2; i++) {
      for(let j = -1; j < 2; j++) {
        if(!this.inBounds(row + i, col + j)) {
          continue;
        }
        let tempItem = this.GRID[row + i][col + j].getItem();
        if(tempItem && tempItem.type == "ENEMY") {
          return true;
          break;
        }
      }
    }
    return false;
  }
  
  // Get a random walkable cell coords
  getWalkCoords = function() {
    print("Attempting to get walkable cell...");
    let cell = null;
    let count = 1;
    while(!cell) {
      print("\tAttempt " + count);
      let tempX = Math.floor(Math.random()*(this.width-1));
      let tempY = Math.floor(Math.random()*(this.height-1));
      
      if(this.GRID[tempX][tempY].collide == 0 && this.GRID[tempX][tempY].getItem() == null) {
        cell = {X: tempX, Y: tempY};
      }
      count++;
    }
    print("Walkable Cell Successfully Found! (" + cell['X'] + "," + cell['Y'] + ")");
    return cell;
  }
  
  // Set the player reference
  setPlayerRef = function(pl) {
    this.playerRef = pl;
    this.GRID[pl.gX][pl.gY].setItem(pl);
    this.pX = pl.gX;
    this.pY = pl.gY;
    // Jump Camera to Player Location
    this.jumpTo(pl.gX, pl.gY);
  }
  
  // Set enemy list reference
  setEnemies = function(list) {
    this.enemies = list;
  }
  
  setItem = function(X, Y, item) {
    if((X > this.GRID.length) || (X < 0) || (Y > this.GRID[X].length) || (Y < 0)) {
      return false;
    }
    this.GRID[X][Y].setItem(item);
    if(item != null) {
      this.GRID[X][Y].collide = 1;
    }
  }
  
  checkCollide = function(gridX, gridY) {
    if(!this.inBounds(gridX, gridY) || this.GRID[gridX][gridY].collide != 0 ||
          this.GRID[gridX][gridY].getItem() != null) {
      return true;
    }
    return false;
  }
  
  /**
   * Move the grid with the player (moves the center anchor of the grid)
   * NOTE: THIS ALSO MOVES THE ENEMIES
   * 
   * Enumeration System:
   * 1 = UP
   * 2 = DOWN
   * 3 = LEFT
   * 4 = RIGHT
   */ 
  move = function(direction) {
    switch(direction) {
      case 1:
        // Move up = GRID down
        this.Y -= this.cellsize;
        break;
      case 2:
        // Move down = GRID up
        this.Y += this.cellsize;
        break;
      case 3:
        // Move left = GRID right
        this.X += this.cellsize;
        break;
      case 4:
        // Move right = GRID left
        this.X -= this.cellsize;
        break;
    }
    
    // Move enemies
    for(let i = 0; i < this.enemies.length; i++) {
      this.enemies[i].move();
    }
  }
  
  // Return if a tile is in the bounds of the grid or not
  inBounds = function(x,y){
    return ((x > 0) && (y > 0) && (x < (this.width - 1)) && (y < (this.height - 1)));
  }
  
  // Return cell at X,Y
  getCell = function(gX, gY) {
    return this.GRID[gX][gY];
  }
  
  // Jump to passed in X and Y location
  jumpTo = function(gX, gY) {
    let target = this.getCell(gX, gY);
    let xDiff = Math.abs(target.X - this.X);
    let yDiff = Math.abs(target.Y - this.Y);
    
    // Jump to X Location
    if(target.X > this.X) {
      this.X -= xDiff;
    } else {
      this.X += xDiff;
    }
    // Jump to Y Location
    if(target.Y > this.Y) {
      this.Y -= yDiff;
    } else {
      this.Y += yDiff;
    }
  }
  
  // Move an item from its old position to its new position - return its new position
  moveItem = function(oldX, newX, oldY, newY) {
    let item = this.GRID[oldX][oldY].getItem(); 
    if(this.inBounds(newX, newY) && !this.checkCollide(newX, newY)) {
      this.GRID[oldX][oldY].setItem(null);
      this.GRID[newX][newY].setItem(item);
      return true;
    }
    return false;
  }
  
  draw = function() {
    let count = 0;
    for(let row = 0; row < this.height; row++) {
      for(let col = 0; col < this.width; col++) {
        this.GRID[row][col].draw();
      }
    }
  }
  
  update = function() {
    // Update location of the player
    this.GRID[this.pX][this.pY].setItem(null);
    this.pX = this.playerRef.gX;
    this.pY = this.playerRef.gY;
    this.GRID[this.pX][this.pY].setItem(this.playerRef);
    
    // Check visibility based on player location (Set grid cell accordinly)
    for(let row = 0; row < this.height; row++) {
      for(let col = 0; col < this.width; col++) {
        let coords = {X: row, Y: col};
        this.GRID[row][col].setVisible(this.playerRef.checkVisible(coords));
      }
    }
    
    // Update Cell Locations
    let currY = this.Y - (((this.height-1)/2) * this.cellsize);
    for(let row = 0; row < this.height; row++) {
      let currX = this.X - ((this.width/2) * this.cellsize);
      for(let col = 0; col < this.width; col++) {
        this.GRID[row][col].setX(currX);
        this.GRID[row][col].setY(currY);
        
        let ene = false;
        for(let i = -1; i < 2; i++) {
          for(let j = -1; j < 2; j++) {
            if(!this.inBounds(row + i, col + j)) {
              continue;
            }
            let tempItem = this.GRID[row + i][col + j].getItem();
            if(tempItem && tempItem.type == "ENEMY") {
              ene = true;
              break;
            }
          }
        }
        this.GRID[row][col].enemySight = ene;
        
        currX += this.cellsize;
      }
      currY += this.cellsize;
      currX = this.X - ((this.width/2) * this.cellsize);
    }
  }
}

































