init = function() {
  cellSize = 15;
  gridHeight = 32;
  gridWidth = 32;
  
  gameover = false;
  
  enemyCount = 10;
  enemies = [];
  // Grid Constructor:  constructor(centerX, centerY, cellSize, width, height)
  print("Build Map Call Below...")
  gridMap = new Grid(0, 0, cellSize, gridHeight, gridWidth);
  
  startCoord = gridMap.getWalkCoords();
  // Player Constructor: constructor(sprite, size, health, sight, gridX, gridY, gridRef)
  player = new Player("player_t", cellSize, 10, 7, startCoord['X'], startCoord['Y'], gridMap);
  
  // Set the player reference in the grid and place the player
  gridMap.setPlayerRef(player);
  
  buildEnemies();
}

// Create the enemies
buildEnemies = function() {
  // Enemy Constructor: constructor(sprite, size, health, sight, gridX, gridY, gridRef)
  for(let i = 0; i < enemyCount; i++) {
    let temp = gridMap.getWalkCoords();
    enemies.push(new Enemy("enemy", cellSize, 3, 4, temp['X'], temp['Y'], gridMap));
    gridMap.setItem(temp['X'], temp['Y'], enemies[i]);
  }
  
  // Pass the enemies back to the gridMap
  gridMap.setEnemies(enemies);
}

draw = function() {
  if(gameover) {
    // Draw Grid
    gridMap.draw();
    
    screen.fillRoundRect(0,-15, 300, 100, 10, "rgba(0,0,0,0.5)");
    screen.drawText("Game Over", 0, 0, 40, "rgb(255,255,255)");
    screen.drawText("You survived for: " + player.moveCount + " moves!", 0, -20, 10, "rgb(255,255,255)");
    screen.drawText("Press Space to Restart...", 0, -30, 10, "rgb(255,255,255)");
    return;
  }
  
  screen.clear();
  // Draw Grid
  gridMap.draw();
  
  // Draw Enemies is called in the grid draw
}

update = function() {
  if(gameover) {
    if(keyboard.SPACE) {
      init();
    }
    return;
  }
  // Update player enemies move when player moves
  player.update();
  
  // Update Grid
  gridMap.update();
  
  // Check for player death
  if(gridMap.checkDeath()) {
    gameover = true;
  }
}