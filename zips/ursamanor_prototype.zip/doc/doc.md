# URSA MANOR

### **Originality:**	
"*Ursa Manor*" is original in its setting and ability to provide a different (albeit fake) constellation for each player. The player is tasked with wrangling
the ghosts into constellation nodes to beat the three levels provided in the current V1 prototype of the game.
### **Technical	Merit:**
"*Ursa Manor's*" technical merit comes from its class based foundation in the underlying code. The entire system is built to scale and grow with the needs of the user.
Below are some examples of this:
* The majority of the UI is spaced based off of the size of the user's screen, to allow for the perfect viewing no matter what size screen is playing.
* The game is built to work procedurally and scale with the needs of the user (the next iteration of the game may have custom settings...).
* The player is able to quickly restart and play the game as many times as they would like.

### **Prototype	Postmortem:**
"*Ursa Manor*" has been a massive learning experience in many ways. I was able to learn about and get a foothold in *microStudio* and allow myself to try and push
the system to its edge. I was able to learn about how I can use the small things in *microScript* to better create a fun game that forced me to think critically and work
outside of the box. 

The easiest part of this prototype was, much to my suprise, creating the introduction. I was suprised by this because when I was coding the introduction, I was frustrated
by the way that *microStudio* worked. Dispite this, I was able to quickly wrap my head around the functionalities and workflows for *microStudo* which opened my eyes to
the possibilities.

The hardest part of this prototype so far has been the random generation of constellations and the hit registering for nodes, ghosts, clicks, and more. I look foreward to
improving this project or working on a new project in the upcoming week.

### **Prototype	Assets:**	
The current version of "*Ursa Manor*" has no sounds, so no credit is due there. All other assets and code are my (*Thomas Campbell*) own work and I take full credit.

### **Prototype	Closest	Other	Game:**
"*Ursa Manor*" has many similar games, however I have to say that I cannot seem to place what inspired it in my head. I wanted to take some of the feelings from
"*Stardew Valley*", however I realized that scope would be too ambitious and my art skills are not on par with that of "Concerned Ape" (*the creator of "Stardew
Valley"*). I tried to take into account all of my experience playing games to create a better overall game experience.

### **High	Concept:**
For too long, "*Ursa Manor*" has lived with the cursed placed upon it, however now it is time for ***YOU*** to come in and clean up the ghosts on the most dangerous night
in a long time... the night of URSA MAJOR!

### **Theme:**
Themes:
1. **Levitating:** I used the idea of ghosts to incorporate levitation into "*Ursa Manor*". This allowed me to have the user "wrangle" the ghosts as they levitated around.
2. **Bear Costume**: While originally I had planned to have the player wear a bear costume, I quickly decided to focus on a different angle with the bear, that of the constellation
of Ursa Major and the family based around bears and bear skins.

Challenges:
1. **Starlight**: Starlight plays a HUGE part in "*Ursa Manor*", it is entirely based around the constellations and stars as the user is tasked with organizing
the ghosts into star patterns.
2. **Moving the Goalposts**: The game doesnt explicitly move the goalpost in the sense that it changes the win condition. However, "*Ursa Manor*" is a constantly
changing game where every constellation is different for every user.

### **Mandated	Variety:**
**Input Type:** Direct? The user moves the ghosts directly with the mouse and is able to directly affect the placement of the ghosts

**Randomness:** The game has randomized levels for each level ***A LOT OF RANDOMNESS***

**Genre**: Management / Story / Puzzle

**Play Style**: Fast paced management of ghosts as they randomly run around. ***COMPETITOR*** - ***JOKER***

### **Prototype	Goal:**	What	game	mechanic	is	this	prototype	evaluating?
This prototype is evaluating just about ever mechanic it encompasses as it allowed me to try entirely new envronments of code and ideas. I wanted to bush my limits on
all of my skills, "*Ursa Manor* has done that."