constel = class {
  constructor(coordList, nodeSize, ghostSize) {
    this.nodeSize = nodeSize;
    this.ghostSize = ghostSize;
    this.nodeCount = 0;
    this.coordList = coordList;
    this.nodeList = [];
    this.ghostList = [];
    this.winner = false;
    this.loser = false;
    
    this.dragging = false;
    this.currGhost = null;
    
    this.buildScene();
  }
  
  
  // Construct the nodes and ghosts
  buildScene = function() {
    // Node Parameters: X, Y, Size
    for(let i = 0; i < (this.coordList.length); i += 2) {
      this.nodeList.push(new this.Node(this.coordList[i], this.coordList[i+1], this.nodeSize));
      print("Building Node " + i/2 + "...");
    }
    this.nodeCount = this.nodeList.length;
    
    // Ghost Parameters: Width, Height, X, Y, HP, Movespeed
    for(let i = 0; i < this.nodeCount + 2; i++) {
      let ghostX = ((Math.floor(Math.random() * screen.width)) - screen.width/2);
      let ghostY = ((Math.floor(Math.random() * screen.height)) - screen.height/2);
      this.ghostList.push(new ghost(this.ghostSize, this.ghostSize, ghostX, ghostY, 3, 0.2));
    }
  }
  
  
  // Count the number of alive ghosts
  aliveCount = function() {
    let count = 0;
    for(var i = 0; i < this.ghostList.length; i++) {
      if(this.ghostList[i].isAlive()) {
        count++;
      }
    }
    return count;
  }
  
  
  // Constel update function
  update = function() {
    // Only update game if user has not won or lost
    if((this.winner == false) && (this.loser == false)) {
      if(this.checkNodes()) {
        this.winner = true;
        return;
      }
      
      if((this.aliveCount() < this.nodeCount) && (this.winner == false)) {
        this.loser = true;
      }
      
      if(mouse.release && this.dragging) {
        this.dragging = false;
        this.currGhost = null;
      }
      
      // Run Ghost Update Function
      for(var i = 0; i < this.ghostList.length; i++) {
        this.ghostList[i].update();
      }
      
      if(this.dragging) {
        this.currGhost.drag(this.dragging, this.currGhost);
      }
      
      if(mouse.press) {
        for(var i = 0; i < this.ghostList.length; i++) {
          // Check if ghost is alive and then if the user has clicked on them
          if(this.ghostList[i].isAlive() && this.ghostList[i].checkHit(mouse.x, mouse.y)) {
            this.dragging = true;
            this.currGhost = this.ghostList[i];
          }
        }
      }
      
      for(var i = 0; i < this.ghostList.length; i++) {
        for(var j = i+1; j < this.ghostList.length; j++) {
          this.ghostList[i].testCollision(this.ghostList[j]);
        }
      }
      
      // Reassign goals if ghost is not on goal cooldown
      for(var i = 0; i < this.ghostList.length; i++) {
        if(!this.ghostList[i].isOnGoalCooldown()) {
          let ghostX = ((Math.floor(Math.random() * screen.width)) - screen.width/2);
          let ghostY = ((Math.floor(Math.random() * screen.height)) - screen.height/2);
          this.ghostList[i].setGoal(ghostX, ghostY);
        }
      }
      
      // Return null to stop moving level foreward
      return null;
      
    } else if(this.winner) {
      // Move level foreward
      if(keyboard.ENTER || keyboard.SPACE) {
        return 1;
      }
      
    } else {
      // Restart the system
      if(keyboard.ENTER || keyboard.SPACE) {
        print("Initiating Start Over Process...")
        return 2;
      }
    }
  }
  
  
  // Check nodes for ghosts over them, return true once all nodes have a ghost over them 
  checkNodes = function() {
    let temp = true
    for(let i = 0; i < this.nodeList.length; i++) {
      for(let j = 0; j < this.ghostList.length; j++) {
        if(!this.nodeList[i].underGhost(this.ghostList[j])) {
          temp = false;
        } else {
          temp = true;
          break;
        }
      }
      if(temp == false) {
        return false;
      }
    }
    return temp;
  }
  
  
  // Constel draw function
  draw = function() {
    if(this.winner) {
      // Draw Normal Backdrop
      screen.drawSprite("moonbackdrop", 0, 0, screen.width, screen.height);
      
      for(let i = 0; i < this.nodeCount; i++) {
        screen.setRadialGradient(this.nodeList[i].getXY()[0], this.nodeList[i].getXY()[1], this.nodeSize+5, "rgb(255,255,255)", "rgb(0,0,0)");
        screen.fillRound(this.nodeList[i].getXY()[0], this.nodeList[i].getXY()[1], this.nodeSize, this.nodeSize);
        this.nodeList[i].draw();
      }
      
      for(let i = 0; i < this.nodeCount-1; i++) {
        let temp = [this.nodeList[i].getXY()[0],this.nodeList[i].getXY()[1],this.nodeList[i+1].getXY()[0],this.nodeList[i+1].getXY()[1]];
        screen.drawLine(temp[0],temp[1],temp[2],temp[3], "rgb(255,255,255)");
      }
      
      screen.fillRoundRect(0, 0, screen.width*(4/5), 50, screen.width*(1/20), "rgba(0,0,0,0.6)")
      screen.drawText("You have banished the curse in this room!", 0, (50/4), (screen.height*(1/15)), "rgb(255,255,255)");
      screen.drawText("Press 'Enter' or 'Space' to start the next level...", 0, -(50/4), (screen.height*(1/20)), "rgb(255,255,255)");
      
    } else if(this.loser) {
      // Draw crumbling castle backdrop
      screen.drawSprite("splashscreenv1updown", 0, 0, screen.width, -screen.height);
      
      screen.fillRect(0, 0, screen.width, screen.height, "rgba(255, 0, 0, 0.6)")
      
      screen.drawText("You failed to protect", 0,-40, 10, "rgb(255,255,255)");
      screen.drawText("URSA MANOR", 0,-60, 50, "rgb(255,255,255)");
      screen.drawText("Press 'Enter' or 'Space' to restart...", 0,-85, 8, "rgb(255,255,255)");
      
    } else {
      // Draw Normal Backdrop
      screen.drawSprite("moonbackdrop", 0, 0, screen.width, screen.height);
      
      this.drawUI();
      
      for(let i = 0; i < this.nodeCount; i++) {
        this.nodeList[i].draw();
      }
      
      for(let i = 0; i < this.ghostList.length; i++) {
        this.ghostList[i].draw();
      }
    }
  }
  
  
  // Draw UI helper function
  drawUI = function() {
    screen.drawText("Level: " + (this.nodeCount-2), -(screen.width*(4/5))/2, -((screen.height/2)-6), 10, "rgb(255,255,255)");
    let curseLevel = ((100/this.ghostList.length) * this.aliveCount());
    screen.drawText("Curse Level: " + curseLevel.toFixed(2) + "%", 0, -((screen.height/2)-6), 10, "rgb(255,255,255)");
    screen.drawText("Ghosts Alive: " + this.aliveCount(), (((screen.width*(4/5))/2)-10), -((screen.height/2)-6), 10, "rgb(255,255,255)");
  }
  
  
  // Nested class to define a node
  Node = class {
    constructor(xPos, yPos, size) {
      this.size = size;
      this.xPos = xPos;
      this.yPos = yPos;
      this.under = false;
    }
    
    getXY = function() {
      return [this.xPos, this.yPos];
    }
    
    // Return the status of a specific ghost being over said node
    underGhost = function(ghostObj) {
      if(!ghostObj.isAlive()) {
        this.under = false;
        return false;
      }
      if((Math.abs(this.xPos - ghostObj.xPos) <= (this.size/2)) &&
         (Math.abs(this.yPos - ghostObj.yPos) <= (this.size/2))) {
        this.under = true;
        return true;
      }
      this.under = false;
      return false;
    }
    
    // Node Draw function
    draw = function() {
      // if(this.under == true) {
      //   screen.fillRound(this.xPos, this.yPos, this.size, this.size, "rgb(255, 255, 255)");
      // }
      screen.drawRound(this.xPos, this.yPos, this.size, this.size, "rgb(245, 96, 66)");
    }
  }
}







