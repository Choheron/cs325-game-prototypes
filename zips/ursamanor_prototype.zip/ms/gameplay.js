gameplay = class {
  init = function() {
    print("Gameplay Initalized...");
    
    // Amount of levels for the user to beat!
    this.levelCount = 3;
    // Current level
    this.currLevel = 1;
    
    this.nodeSize = 30;
    
    // Constel Parameters: Coordinate List [X,Y], Node Size, Ghost Size
    this.currList = this.generateCoords(this.currLevel + 2);
    this.currConst = new constel(this.currList, this.nodeSize, this.nodeSize-5);
  }
  
  generateCoords = function(level) {
    let out = [];
    for(var i = 0; i < level; i++) {
      do {
        this.widthCalc = screen.width - this.nodeSize;
        this.heightCalc = screen.height - this.nodeSize;
        this.xPos = Math.round(((Math.floor((Math.random() * this.widthCalc)) - (this.widthCalc/2))/this.nodeSize))*this.nodeSize;
        this.yPos = Math.round(((Math.floor((Math.random() * this.heightCalc)) - (this.heightCalc/2))/this.nodeSize))*this.nodeSize;
      } while(out.indexOf(this.xPos, 2) != -1 || out.indexOf(this.yPos, 2) != -1);
      out.push(this.xPos);
      out.push(this.yPos);
    }
    print(out.toString());
    return out;
  }
  
  update = function() {
    let levelComp = this.currConst.update();
    if(levelComp == 1) {
      print("LEVEL COMPLETE: Finished level " + this.currLevel + '...')
      if(this.currLevel > this.levelCount) {
        // End Game after three levels are completed
        return 1; 
      }
      this.nextLevel();
    } else if(levelComp == 2) {
      return 2;
    }
  }
  
  nextLevel = function() {
    this.currLevel++;
    
    this.currList = this.generateCoords(this.currLevel + 2);
    this.currConst = new constel(this.currList, this.nodeSize, this.nodeSize-5);
  }
  
  
  draw = function() {
    this.currConst.draw();
  }
}
