initMenu = function() {
  starAlive = false;
  drawInstructions = false;
  starStep = 0;
  shootingStarX = ((Math.random() * 360) - 180);
  shootingStarY = (Math.random() * 50) + 50;
  
  setupMenu();
}

menuUpdate = function() {
  starStep++;
  
  if(keyboard.release.I && !drawInstructions) {
    drawInstructions = true;
  } else if(drawInstructions && keyboard.release.I) {
    drawInstructions = false;
  }
}

menuDraw = function() {
  setupMenu();
  if(!starAlive && starStep >= 120 && !drawInstructions) {
    starAlive = true;
    starStep = 0;
    shootingStarX = ((Math.random() * 360) - 180);
    shootingStarY = (Math.random() * 50) + 50;
  } else if(starAlive) {
    sprites["shootingstar"].setFrame(starStep);
    screen.drawSprite(sprites["shootingstar"], shootingStarX, shootingStarY, 30);
    if(starStep >= 10) {
      starAlive = false;
      starStep = 0;
    }
  }

  if(starStep < 30 || (starStep > 60 && starStep < 90)) {
    screen.drawText("Press \"Enter\" to start...", 0,-83, 8, "rgb(255,255,255)");
  } else {
    screen.drawText("Press \"I\" to toggle instructions...", 0,-93, 8, "rgb(255,255,255)");
  }
}

setupMenu = function() {
  screen.clear();
  screen.drawSprite("splashscreenv1", 0, 0, screen.width, screen.height);
  screen.drawText("URSA MANOR", 0,-60, 50, "rgb(255,255,255)");
  
  if(drawInstructions) {
    screen.fillRoundRect(0, 40, screen.width*(3/4), screen.height/2, 10,"rgba(0,0,0,0.5)");
    
    screen.drawText("Welcome to \"Ursa Manor\"!", 0, ((screen.height*(3/4))/2)-10, 10, "rgb(255,255,255)");
    screen.drawText("You have been called here to banish the curse on URSA MANOR...", 0, ((screen.height*(3/4))/2)-20, 10, "rgb(255,255,255)");
    screen.drawText("To do so, you must wrangle the ghosts into", 0, ((screen.height*(3/4))/2)-30, 10, "rgb(255,255,255)");
    screen.drawText("the constellation shapes as they levitate around!", 0, ((screen.height*(3/4))/2)-40, 10, "rgb(255,255,255)");
    screen.drawText("Be careful! If the ghosts touch too much, they can die!", 0, ((screen.height*(3/4))/2)-50, 10, "rgb(255,255,255)");
    screen.drawText("If enough ghosts die, the curse takes hold...", 0, ((screen.height*(3/4))/2)-60, 10, "rgb(255,255,255)");
  }
}





