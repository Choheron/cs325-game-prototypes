ghost = class {
  constructor(width, height, x, y, hp, moveSpeed) {
    this.width = width;
    this.height = height;
    this.xPos = x;
    this.yPos = y;
    this.moveSpeed = moveSpeed;
    this.maxHP = hp;
    this.hp = hp;
    
    this.alive = true;
    // Ghosts start with cooldown to avoid insta-death
    this.onCooldown = true;
    this.cooldownMAX = 60;
    this.cooldown = this.cooldownMAX;
    
    this.onGoalCooldown = false;
    this.goalCooldownMAX = 120;
    this.goalCooldown = this.goalCooldownMAX;
    this.xGoal = x;
    this.yGoal = y;
  }
  
  
  update = function() {
    // Only Update if Alive
    if(this.alive) {
      // Move towards goal coordinates
      if(this.xPos != this.xGoal) {
        if(this.xPos < this.xGoal) {
          this.xPos += this.moveSpeed;
        } else {
          this.xPos -= this.moveSpeed;
        }
      }
      if(this.yPos != this.yGoal) {
        if(this.yPos < this.yGoal) {
          this.yPos += this.moveSpeed;
        } else {
          this.yPos -= this.moveSpeed;
        }
      }
    }
    
    // Increment damage cooldown if on cooldown
    if(this.onCooldown) {
      this.cooldown--;
    }
    
    // Increment goal cooldown if on cooldown
    if(this.onGoalCooldown) {
      this.goalCooldown--;
    }
    
    // Turn off cooldown after half a second (assuming user is at 60 fps)
    if(this.cooldown <= 0) {
      this.onCooldown = false;
      this.cooldown = this.cooldownMAX;
    }
    
    // Update and increment goal cooldown
    if(this.goalCooldown <= 0) {
      this.onGoalCooldown = false;
      this.goalCooldown = this.goalCooldownMAX;
    }
  }
  
  
  // Test collision with another ghost and apply damage to both
  testCollision = function(other) {
    // Test for dead ghosts
    if(!this.alive || !other.isAlive() || this.onCooldown || other.isOnCooldown()) {
      return;
    }
    if((Math.abs(this.xPos - other.getPos()[0]) <= ((this.width/2) + (other.width/2))) &&
       (Math.abs(this.yPos - other.getPos()[1]) <= ((this.height/2) + (other.height/2)))) {
      this.takeDamage(1);
      other.takeDamage(1);
    }
  }
  
  
  // Getters for width and height
  getWidth = function() {
    return this.width;
  }
  
  
  getHeight = function() {
    return this.height;
  }
  
  
  // Return position of ghost
  getPos = function() {
    return [this.xPos, this.yPos];
  }
  
  
  // Return status of damage cooldown
  isOnCooldown = function() {
    return this.onCooldown;
  }
  
  
  // Return status of goal cooldown
  isOnGoalCooldown = function() {
    return this.onGoalCooldown;
  }
  
  
  // Allow user to drag ghosts around
  drag = function(isDragging, ghost) {
    if(isDragging && this == ghost) {
      this.xPos = mouse.x;
      this.yPos = mouse.y;
    }
  }
  
  
  // Sets a new goal location.
  setGoal = function(xCoord, yCoord) {
    if(!this.onGoalCooldown) {
      this.xGoal = xCoord;
      this.yGoal = yCoord;
      
      this.onGoalCooldown = true;
    }
  }
  
  
  // Returns a boolean on the alive state of the ghost
  isAlive = function() {
    return this.alive;
  }
  
  
  // Take damage if damage cooldown isnt active, then activate cooldown
  takeDamage = function(damage) {
    if(!this.onCooldown) {
      this.hp -= damage;
      if(this.hp <= 0) {
        this.alive = false;
      }
      this.onCooldown = true;
    }
  }
  
  
  // Check to see if coords provided fall into the ghosts hitbox
  checkHit = function(hitX, hitY) {
    if((hitX > (this.xPos-(this.width*(3/4)))) && (hitX < (this.xPos+(this.width*(3/4))))) {
      if((hitY > (this.yPos-(this.height*(3/4)))) && (hitY < (this.yPos+(this.height*(3/4))))) {
        return true;
      }
    }
  }
  
  
  // Ghost Draw Function, to be called for every ghost
  draw = function() {
    if(this.alive) {
      if(((this.cooldown > this.cooldownMAX*(1/4)) && ((this.cooldown < this.cooldownMAX*(1/2)))) || 
          (this.cooldown > this.cooldownMAX*(3/4))) {
        // Draw Ghost Sprite
        screen.drawSprite("ghost", this.xPos, this.yPos, this.width, this.height);
      }
      // Draw Health Bar If NOT on Cooldown
      if(this.cooldown == this.cooldownMAX) {
        let healthY = (this.yPos - (this.height*(3/4)));
        let hpWidth = (((this.width/this.maxHP)*this.hp)*(3/4));
        screen.fillRoundRect(this.xPos, healthY, hpWidth, this.height*(1/4), this.width*(1/8), "rgb(255,0,0)");
        screen.drawRoundRect(this.xPos, healthY, this.width*(3/4), this.height*(1/4), this.width*(1/8), "rgb(255,255,255)");
      }
    }
  }
  
}































