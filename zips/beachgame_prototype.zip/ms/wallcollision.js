WallCollision = class {
  constructor(width, height, cellSize, map) {
    this.width = width;
    this.height = height;
    this.cellSize = cellSize;
    this.ref = map;
    
    this.map = [];
    this.buildMap();
  }
  
  buildMap = function() {
    // Fill map with inital empty values 
    for(let i = 0; i < this.height; i++) {
      let temp = [];
      for(let j = 0; j < this.width; j++) {
        // Set values depending on sprite in map
        // NOTE map.get USES ORIGIN AT BOTTOM LEFT NOT TOP LEFT
        if(this.ref.get(j, (this.height - i - 1)).indexOf("wall") != -1) {
          temp.push(1);
        } else {
          temp.push(0);  
        }
      }
      this.map.push(temp);
    }
  }
  
  set = function(x, y, val) {
    this.map[y][x] = val;
  }
  
  checkCollide = function(xPos, yPos, playerWidth, playerHeight) {
    
  }
  
  // FOR DEBUGGING
  draw = function() {
    let currX = -(screen.width/2) + (this.cellSize/2);
    let currY = (screen.height/2) - (this.cellSize/2);
    
    for(let i = 0; i < this.height; i++) {
      for(let j = 0; j < this.width; j++) {
        screen.drawText(this.map[i][j], currX, currY, 10, "rgb(255, 0, 0)");
        currX += this.cellSize;
      }
      currX = -(screen.width/2) + (this.cellSize/2);
      currY -= this.cellSize;
    }
  }
}