init = function() {
  // Initalize inventory
  // constructor(size, stack, autoOrganize, bgColor, cellColor, cellBorderColor, rounded)
  i = new Inventory(30, true, true, "rgb(201, 161, 152)", "rgb(255,255,255)", "rgb(0,0,0)", "rgb(0,0,0)", true);
  
  // Initalize reference to map
  map = maps["map1"];
  // Initalize map collision skeleton
  // constructor(width, height, cellSize)
  collide = new WallCollision(32, 18, (screen.width/32), map);
  
  // Initalize new player
  // constructor(startX, startY, sprite, width, height)
  player = new Player(0, 0, "player", (screen.width/32)-1, (screen.width/32)-1);
  
  // Debug variable for testing
  debug = false;
}

update = function() {
  // Update Inventory
  i.update();
  
  // Update Player
  player.update();
  
  
  if(keyboard.press.ESCAPE) {
    print(i.toString(true));
    debug = !debug;
  }
}

draw = function() {
  // Draw Base Map
  screen.drawMap("map1", 0, 0, screen.width, screen.height)
  
  // Draw Player
  player.draw();
  
  // Draw debug information if toggled
  if(debug) {
    collide.draw();  
  }
  // i.draw();
}