Item = class {
  // Params:
  // - String name (Name of Item)
  // - String sprite (name of sprite corresponding to item)
  // - int ID
  constructor(name, sprite, ID) {
    this.name = name;
    this.sprite = sprite;
    this.ID = ID;
  }
  
  // Draw the items sprite, provided X, Y, Width, and Height
  draw = function(xPos, yPos, width, height) {
    screen.drawSprite(this.sprite, xPos, yPos, width, height);
  }
  
  // Return name of item
  getName = function() {
    return this.name;
  }
  
  // Set name of item to passed in string
  setName = function(newName) {
    this.name = newName;
  }
  
  // Return sprite string
  getSprite = function() {
    return this.sprite;
  }
  
  // Set sprite of item to passed in string
  setName = function(newSprite) {
    this.sprite = newSprite;
  }
  
}