Inventory = class {
  // Params:
  // - int Size (Directly corresponds to amount of spaces in inventory) [NOT CURRENTLY SUPPORTED]
  // - bool stack (True if objects of the same name should stack, false if not) [NOT CURRENTLY SUPPORTED]
  // - autoOrganize (True if the inventory should auto organize the items by name)
  // ===== UI PARAMETERS
  // - BG Color (String rgb corresponding to the background color)
  // - Cell Color (String rgb corresponding to the color of the cells)
  // - Cell Border Color (String rgb corresponding to the border color of the cells)
  // - Item Quanitity Text Color (String rgb corresponding to the item text color in the inventory)
  // - Rounded? (Boolean corresponding to if the UI is to be rounded or not)
  constructor(size, stack, autoOrganize, bgColor, cellColor, cellBorderColor, itemTxtColor, rounded) {
    this.autoOrg = autoOrganize;
    
    this.bgCol = bgColor;
    this.cellCol = cellColor;
    this.cellBCol = cellBorderColor;
    this.textCol = itemTxtColor;
    this.rounded = rounded;
    this.hoverItem = null;
    
    this.count = 0;
    this.warehouse = [];
    
    this.full = false;
  }
  
  
  draw = function() {
    this.drawUI();
    
    if(this.hoverItem) {
      // DRAW HOVER ITEM CODE HERE
    }
  }
  
  drawUI = function() {
    if(this.rounded) {
      screen.fillRoundRect(0, 0, screen.width*(4/5), screen.height*(4/5), 10, this.bgCol);
      let xPos = (((screen.width - 30)*(4/5)/10) - (screen.width*(4/5)/2));
      let xInc = ((screen.width - 30)*(4/5)/10);
      let yPos = -(((screen.height - 30)*(4/5)/5) - (screen.height*(4/5)/2));
      let yInc = ((screen.height - 30)*(4/5)/5);
      for(let i = 1; i <= 50; i++) {
        // Draw inventory slots
        screen.fillRoundRect(xPos, yPos, screen.width*(4/5)/12, screen.width*(4/5)/12, 1, this.cellCol);
        screen.drawRoundRect(xPos, yPos, screen.width*(4/5)/12, screen.width*(4/5)/12, 1, this.cellBCol);
        // Draw item if there is one in this slot
        if(this.warehouse[i - 1]) {
          this.warehouse[i - 1]["obj"].draw(xPos, yPos, screen.width*(4/5)/12, screen.width*(4/5)/12);
          if(this.warehouse[i - 1]["quantity"] > 1) {
            let textX = xPos + ((screen.width*(4/5)/12)/2) - 4;
            let textY = yPos + ((screen.width*(4/5)/12)/2) - 3;
            screen.drawText("x" + this.warehouse[i - 1]["quantity"], textX, textY, 5, this.textCol);
          }
        }
        // Increment cell drawing
        xPos += xInc;
        if(i % 10 == 0) {
          yPos -= yInc;
          xPos = (((screen.width - 30)*(4/5)/10) - (screen.width*(4/5)/2));
        }
      }
    } else {
      screen.fillRect(0, 0, screen.width*(4/5), screen.height*(4/5), this.bgCol);
      let xPos = (((screen.width - 30)*(4/5)/10) - (screen.width*(4/5)/2));
      let xInc = ((screen.width - 30)*(4/5)/10);
      let yPos = -(((screen.height - 30)*(4/5)/5) - (screen.height*(4/5)/2));
      let yInc = ((screen.height - 30)*(4/5)/5);
      for(let i = 1; i <= 50; i++) {
        // Draw Inventory Slots
        screen.fillRect(xPos, yPos, screen.width*(4/5)/12, screen.width*(4/5)/12, this.cellCol);
        screen.drawRect(xPos, yPos, screen.width*(4/5)/12, screen.width*(4/5)/12, this.cellBCol);
        //Draw item if there is one in this slot
        if(this.warehouse[i - 1]) {
          this.warehouse[i - 1]["obj"].draw(xPos, yPos, screen.width*(4/5)/12, screen.width*(4/5)/12);
          if(this.warehouse[i - 1]["quantity"] > 1) {
            let textX = xPos + ((screen.width*(4/5)/12)/2) - 4;
            let textY = yPos + ((screen.width*(4/5)/12)/2) - 3;
            screen.drawText("x" + this.warehouse[i - 1]["quantity"], textX, textY, 5, this.textCol);
          }
        }
        // Increment cell drawing
        xPos += xInc;
        if(i % 10 == 0) {
          yPos -= yInc;
          xPos = (((screen.width - 30)*(4/5)/10) - (screen.width*(4/5)/2));
        }
      }
    }
  }
  
  
  update = function() {
    if(keyboard.release.S) {
      this.sort();
    }
  }
  
  
  // Returns the index of passed in item in inventory, returns -1 if not found.
  // (Item must be of custom type ITEM [INCLUDED IN THIS PACKAGE])
  find = function(item) {
    for(let i = 0; i < this.count; i++) {
      if(this.warehouse[i]["obj"] == item) {
        return i;
      }
    }
    return -1;
  }
  
  
  // Adds an item to the inventory (Item must be of custom type ITEM [INCLUDED IN THIS PACKAGE])
  addItem = function(item) {
    let index = this.find(item);
    if(index == -1) {
      // Return false and print to console if inventory is full and item cannot be stacked.
      if(this.full) {
        console.log("Inventory ERROR!");
        console.log("ERROR:\t Item: " + item.toString() + " cannot be added!");
        console.log("REASON:\t Item cannot stack and inventory is FULL");
        return false;
      }
      this.warehouse.push({obj: item, quantity: 1});
      this.count++;
      if(this.count == 30) {
        this.full = true;
      }
      if(this.autoOrg) {
          this.sort();
      }
    } else {
      this.warehouse[index]["quantity"]++;
    }
  }
  
  // Remove item from inventory and return it 
  // (Item must be of custom type ITEM [INCLUDED IN THIS PACKAGE])
  removeItem = function(item) {
    let index = this.find(item);
    if(index == -1) {
      console.log("Inventory WARNING!");
      console.log("WARN:\t Item: " + item.getName() + " cannot be removed!");
      console.log("REASON:\t Item not found in inventory!");
      return false;
    } else {
      this.warehouse[index]["quantity"]--;
      let out = this.warehouse[index];
      if(this.warehouse[index]["quanitity"] == 0) {
          this.warehouse.splice(index, index + 1);
          this.count--;
      }
      return out;
    }
  }
  
  
  sort = function() {
      this.warehouse.sort(function(a, b) {
          var textA = a["obj"].getName().toUpperCase();
          var textB = b["obj"].getName().toUpperCase();
          return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
      });
  }


  // toString function (If passed in value of debug is true, return information in a FORMATTED debug string.)
  toString = function(debug) {
      // Return simple debug if no arguments are passed in or if debug is false
      if(arguments.length == 0) {
          debug = false;
      }
      if(debug) {
          let out = "";
          out += "INVENTORY INFROMATION:\n";
          out += "Capacity: " + 30 + " [SIZE CUSTOMIZATION CURRENTLY LOCKED AT 30]\n";
          out += "Current Load: " + this.count + "\n";
          out += "Stackable: " + true + " [STACK ENABLE/DISABLE IS NOT CURRENTLY SUPPORTED]\n";
          out += "Auto Organize: " + this.autoOrg + "\n";
          out += "===== UI PARAMS:\n";
          out += "Background Color: " + this.bgCol + "\n";
          out += "Cell Color: " + this.cellCol + "\n";
          out += "Cell Border Color: " + this.cellBCol + "\n";
          out += "Rounded: " + this.rounded + "\n";
          out += "INVENTORY CONTENTS:\n";
          for(let c = 0; c < this.count; c++) {
              out += "\t" + (c + 1) + ". " + this.warehouse[c]["obj"].getName() + " (x" + this.warehouse[c]["quantity"] + ")\n";
          }
          return out;
      }
      return "Inventory Contents: " + this.warehouse;
  }
}





















