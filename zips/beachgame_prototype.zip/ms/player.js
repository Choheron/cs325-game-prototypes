Player = class {
  constructor(startX, startY, sprite, width, height) {
    this.X = startX;
    this.Y = startY;
    
    this.sprite = sprite;
    this.width = width;
    this.height = height;
    this.speed = 0.3;
  }
  
  setSpeed = function(speed) {
    this.speed = speed;
  }
  
  draw = function() {
    screen.drawSprite(this.sprite, this.X, this.Y, this.width, this.height);
  }
  
  update = function() {
    // Movement Calculations
    if(keyboard.W) {
      this.Y += this.speed;
    }
    if(keyboard.S) {
      this.Y -= this.speed;
    }
    if(keyboard.A) {
      this.X -= this.speed;
    }
    if(keyboard.D) {
      this.X += this.speed;
    }
  }
}