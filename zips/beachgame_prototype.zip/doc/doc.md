# BEACH BAR - PROTOTYPE SUBMISSION (2A)

### **Originality:**	
Beach bar is orginal in that it works to create an interesting game about running a food joint/bar using interesting backend code and providing a fun and calming
experience for the player.


### **Technical	Merit:**
Technical merit comes from its class based foundation in the underlying code. The game also holds technical merit in that it allows for inventories and other
higher level game interactions.

Below are some examples of this:
* The majority of the UI is spaced based off of the size of the user's screen, to allow for the perfect viewing no matter what size screen is playing.
* The collision system reactively responds to my changes in the map, allowing for constant changes to the bar while developing and POSSIBLY allowing for player editing
of the resturant itself!
* DEBUG COLLISION EXAMPLES CAN BE SEEN IF THE USER PRESSES "ESCAPE" while in the prototype game!

### **Prototype	Postmortem:**
This game has been tougher as I have been strapped for time due to work and other projects, so I was unable to dedicate as much time as I would have liked on this
prototype. However, I find that I have managed to find a game that I am very excited about and I am ready to continue working on in the future.

### **Prototype	Assets:**	
The current version of the game has no sounds, so no credit is due there. All other assets and code are my (*Thomas Campbell*) own work and I take full credit.

### **Prototype	Closest	Other	Game:**
This game has been inspired by other crafting/tycoon games where the user can build and run a resturant while also trying to be fast and maintain income. This is close
to games like "*Stardew Valley*" and "*Resturant Tycoon*".

### **High	Concept:**
You are the owner of a bar on the beach... it also happens that your main clientelle is CRABS! And they are pretty quiet to boot! You must work to keep the crabs happy
and serve them well!

### **Theme:**
Themes:
1. **NZ beach crab art silent** - The game is centered around a beach and crabs! And currently there are no sounds!

### **Mandated	Variety:**
**Input Type:** Direct, the user controls the crab and the resturant with their mouse and keyboard.

**Randomness:** The game has randomized orders by the crabs, which causes the user to need to react to the specific orders of the crabs.

**Genre**: Management / Tycoon / Crafting

**Play Style**: Calming OR Fast Paced play, there really is no true loss condition at this point so the user can always try to relax.

### **Prototype	Goal:**	What	game	mechanic	is	this	prototype	evaluating?
This prototype is evaluating an entirely new type of game from my previous one. This game is 100% different from my previous one and allows me to test colloisions,
inventory mechanics, random orders, pathing, etc.