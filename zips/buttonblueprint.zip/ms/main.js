init = function() {
  // constructor(name, xPos, yPos, width, height, text, textSize, textColor, baseColor, selColor, bordColor, rounded)
  testButton = new button("test", 0, 25, 80, 20, "TEST BTN", 10, "rgb(0,0,0)", "rgb(66,191,245)", "rgb(66,81,245)", "rgb(0,0,0)", true);
  testButton2 = new button("test2", 0, 0, 60, 10, "TEST BTN 2", 5, "rgb(0,0,0)", "rgb(255, 59, 59)", "rgb(148, 34, 34)", "rgb(0,0,0)", true);
}

update = function() {
  testButton.update();
  testButton2.update();
}

draw = function() {
  screen.fillRect(0,0,screen.width,screen.height, "rgb(138, 138, 138)");
  
  testButton.draw();
  testButton2.draw();
}