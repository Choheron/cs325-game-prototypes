NOTE: This is the microscript port of the javascript button I have created, its current version may be older than the javasript version depending on updates.

Foreward: Please let me know if there are any improvements people would like to see! Or any additional functionalities as well as possible bugs!
```
======================== Button Class MICROSCRIPT PORT ========================
 Author: Thomas Campbell
 Credit Requirements: 
  - Please just include in your description or any applicable credit area that you used this code for your buttons! 
  - Feel free to use this in ANY project both commercial or personal!
  
  Small Description: At surface level this looks like only a toggle button, however It can be used as a push button if the user is searching for a toggle in the 
  update function to then just toggle it back off after catching it being true. 

 Constructor Parameters:
 Button Constructor: new button(name, xPos, yPos, width, height, text, textSize, textColor, baseColor, selColor, bordColor, rounded);
 1. name: STRING - Name of the button (NOT THE TEXT DISPLAYED).
 2. xPos: NUMBER - X position of the center of the button.
 3. yPos: NUMBER - Y position of the center of the button.
 4. width: NUMBER - Desired width of the button
 5. height: NUMBER - Desired height of the button
 6. text: STRING/LIST - Desired text for button (WILL OVERFLOW) ((SUPPLY AN ARRAY OF STRINGS IF YOU WANT MULTIPLE LINES OF TEXT))
 7. testSize: NUMBER - Desired size for text in button
 8. textColor: COLOR(STRING) - String in the following format: "rgba(RED, GREEN, BLUE, ALPHA)", text will be this color.
 9. baseColor: COLOR(STRING) - String in the following format: "rgba(RED, GREEN, BLUE, ALPHA)", this color will be displayed
         when the button is NOT selected.
 10. selColor: COLOR(STRING) - String in the following format: "rgba(RED, GREEN, BLUE, ALPHA)", this color will be displayed
         when the button IS selected.
 11. bordColor: COLOR(STRING) - String in the following format: "rgba(RED, GREEN, BLUE, ALPHA)", this will be the border color.
 12. rounded: BOOL - Boolean value signifying if the button should have rounded edges or not when drawn.

 Use Functions:
 1. update():
     PARAMETERS: NONE
     RETURN: STRING - Name of button will be returned when it is toggled on. NULL - Return null if button is not selected.
     DESCRIPTION: To be called whenever the script using this class updates, if there are multiple buttons, they should all have an individual call to
         each button's update function.

 2. draw():
     PARAMETERS: NONE
     DESCRIPTION: To be called whenever the script using this class draws, if there are multiple buttons, they should all have an individual call to
         each button's draw function.

 3. setXY(xPos,yPos):
     PARAMETERS: 
         1. xPos: NUMBER - New X position of the button.
         2. yPos: NUMBER - New Y position of the button.
     RETURN: NONE

 4. getXY():
     PARAMETERS: NONE.
     RETURN: A list in the following format: [xPos, yPos].

 5. isSelected(): 
     PARAMETERS: NONE
     RETURN: BOOL - True if button is selected, false if button is not selected.

 6. setSelected(selected): 
     PARAMETERS:
         1. selected: BOOLEAN - True if the user would like to toggle the button to selected, false if they would like the button to not be selected.
     RETURN: BOOL - True if button is selected, false if button is not selected.

 7. toggle(): 
     PARAMETERS: NONE
     RETURN: BOOL - True if button was TOGGLED to become selected, False if button was TOGGLED to become unselected.
 
 8. setText(text):
     PARAMETERS:
         1. text: STRING/LIST - Desired text for button (WILL OVERFLOW) ((SUPPLY AN ARRAY OF STRINGS IF YOU WANT MULTIPLE LINES OF TEXT)).
     RETURN: NONE

 9. getText(type):
     PARAMETERS:
         1. type: BOOL - A boolean value passed in that is only accounted for if the button is a multi-line object. If the user passes in a TRUE, 
               they will recieve all lines of the text in a single string [WITH A SPACE INBETWEEN EACH ELEMENT], if FALSE is passed in, they will 
               recieve a list similar to how it was passed in.
     RETURN: STRING/LIST - Returns the current text for the button, if it is a multiline button the user can decide if they would like
         all of the strings returned as a whole or as a list [SIMILAR TO HOW THEY WERE PASSED IN].

 10. setName(name):
     PARAMETERS:
         1. name: STRING/LIST - Desired name for button.
     RETURN: NONE

 11. getName():
     PARAMETERS: NONE
     RETURN: STRING - Current name of this button.

 Background Functions (can still be called outside of the class):
 1. checkHit(hitX, hitY):
     PARAMETERS:
         1. hitX: NUMBER - X value of mouse or tap.
         2. hitY: NUMBER - Y value of mouse or tap.
     RETURN: BOOL - True if the X and Y value fall collide with the button (the button has been pressed), False if not.
```